# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyleft (c) 2015-2099 宝塔软件(http://bt.cn) All lefts reserved.
# +-------------------------------------------------------------------
# | Author: 黄文良 <287962566@qq.com>
# | Maintainer: linxiao
# +-------------------------------------------------------------------
# +--------------------------------------------------------------------
# |   宝塔网站监控报表
# +--------------------------------------------------------------------
from __future__ import absolute_import, division, print_function

import calendar
import datetime
import json
import os
import re
import sys
import time
import ipaddress

import psutil

_ver = sys.version_info
is_py2 = (_ver[0] == 2)
is_py3 = (_ver[0] == 3)

os.chdir("/www/server/panel")
sys.path.insert(0, "class/")

import public
from BTPanel import cache, get_input
from panelAuth import panelAuth

from lua_maker import LuaMaker
from total_migrate import total_migrate
from tsqlite import tsqlite
import total_tools as tool


class total_main:
    __plugin_path = '/www/server/total'
    __frontend_path = '/www/server/panel/plugin/total'
    __config = {}
    close_file = "/www/server/total/closing"
    data_dir = None
    history_data_dir = None
    global_region = {}
    access_defs = [
        "get_site_overview_sum_data",
        "get_ip_stat",
        "get_uri_stat",
        "generate_area_stat",
        "get_area_stat",
        "init_ts",
        "get_referer_stat",
        "update_spiders_from_cloud"
        ]

    def __init__(self):
        pass

    def log(self, msg):
        log_file = os.path.join(self.__frontend_path, "error.log")
        if is_py3:
            with open(log_file, "a", encoding="utf-8") as fp:
                fp.write(msg + "\n")
        else:
            with open(log_file, "a") as fp:
                fp.write(msg + "\n")

    def flush_data(self, site):
        try:
            import random
            import time
            flush_url = "http://127.0.0.1:80/bt_total_flush_data?time="+str(time.time()) + str(random.randint(0, 100)) + "\&server_name="+site
            public.ExecShell("curl "+flush_url)
        except Exception as e:
            self.log("Flush data error："+str(e))
        
    def get_config(self, site=None):
        if self.__config and site in self.__config.keys(): return self.__config[site]
        data = public.readFile(self.__plugin_path + '/config.json')
        config = json.loads(data)
        if site in config.keys():
            global_config = config["global"]
            for k, v in global_config.items():
                if k not in config[site].keys():
                    config[site][k] = global_config[k]
            if not global_config["monitor"]:
                config[site]["monitor"] = False
            self.__config[site] = config[site]
        else:
            self.__config[site] = config["global"]
        return self.__config[site]
        

    def set_status(self, get):
        self.__read_config()
        self.__config['global']["monitor"] = not self.__config['global']['monitor']
        self.__write_config()
        self.__write_logs("设置网站监控插件状态为[%s]" % (self.__config['global']['monitor'],))
        return public.returnMsg(True, '设置成功!')

    def set_site_value(self, get):
        self.__read_config()
        site = ""
        if "siteName" in get:
            site = get.siteName
        if "site" in get:
            site = get.site

        if type(self.__config[site][get.s_key]) == bool:
            get.s_value = not self.__config[site][get.s_key]
        elif type(self.__config[get.siteName][get.s_key]) == int:
            get.s_value = int(get.s_value)
        self.__config[get.siteName][get.s_key] = get.s_value
        self.__write_logs(
            "设置网站[%s]的[%s]配置项为[%s]" % (site, get.s_key, get.s_value))
        self.__write_config()
        return public.returnMsg(True, '设置成功!');

    def get_total_ip(self, get):
        self.__read_config()
        data = {}
        data['total_ip'] = self.__config['sites'][get.siteName]['total_ip']
        data['total_uri'] = self.__config['sites'][get.siteName]['total_uri']
        return data

    def add_total_ip(self, get):
        self.__read_config()
        if get.ip in self.__config['sites'][get.siteName][
            'total_ip']: return public.returnMsg(False, '指定URI已存在!');
        self.__config['sites'][get.siteName]['total_uri'][get.uri_name] = 0;
        self.__write_logs("向网站[%s]添加自定义统计IP[%s]" % (get.siteName, get.ip))
        self.__write_config()
        return public.returnMsg(False, '添加成功!');

    def remove_total_ip(self, get):
        self.__read_config()
        del (self.__config['sites'][get.siteName]['total_ip'][get.ip])
        self.__write_logs("从网站[%s]删除自定义统计IP[%s]" % (get.siteName, get.ip))
        self.__write_config()
        return public.returnMsg(False, '删除成功!');

    def get_total_uri(self, get):
        self.__read_config()
        return self.__config['sites'][get.siteName]['total_uri']

    def add_total_uri(self, get):
        self.__read_config()
        if get.uri_name in self.__config['sites'][get.siteName][
            'total_uri']: return public.returnMsg(False, '指定URI已存在!');
        self.__config['sites'][get.siteName]['total_uri'][get.uri_name] = 0;
        self.__write_logs(
            "向网站[%s]添加自定义统计URI[%s]" % (get.siteName, get.uri_name))
        self.__write_config()
        return public.returnMsg(False, '添加成功!');

    def remove_total_uri(self, get):
        self.__read_config()
        del (self.__config['sites'][get.siteName]['total_uri'][get.uri_name])
        self.__write_logs(
            "从网站[%s]删除自定义统计URI[%s]" % (get.siteName, get.uri_name))
        self.__write_config()
        return public.returnMsg(False, '删除成功!');

    def get_log_exclude_status(self, get):
        site = ""
        if "siteName" in get:
            site = get.siteName
        if "site" in get:
            site = get.site
        self.__read_config()
        return self.__config[site]['exclude_status']

    def add_log_exclude_status(self, get):
        site = ""
        if "siteName" in get:
            site = get.siteName
        if "site" in get:
            site = get.site
        self.__read_config()
        if get.status in self.__config[site]['exclude_status']: 
            return public.returnMsg(False, '指定响应状态已存在!');
        self.__config[site]['exclude_status'].insert(0, get.status)
        self.__write_logs("向网站[%s]添加响应状态排除[%s]" % (site, get.status))
        self.__write_config()
        return public.returnMsg(False, '添加成功!');

    def remove_log_exclude_status(self, get):
        site = ""
        if "siteName" in get:
            site = get.siteName
        if "site" in get:
            site = get.site
        self.__read_config()
        status = get.status
        self.__write_logs("从网站[%s]删除响应状态排除[%s]" % (site, status))
        self.__config[site]['exclude_status'].remove(status)
        self.__write_config()
        return public.returnMsg(False, '删除成功!');

    def get_log_exclude_extension(self, get):
        site = ""
        if "siteName" in get:
            site = get.siteName
        if "site" in get:
            site = get.site
        return self.__config[site]['exclude_extension']

    def add_log_exclude_extension(self, get):
        site = ""
        if "siteName" in get:
            site = get.siteName
        if "site" in get:
            site = get.site
        self.__read_config()
        if get.ext_name in self.__config[site]['exclude_extension']: return public.returnMsg(False,
                                                              '指定扩展名已存在!');
        self.__config[site]['exclude_extension'].insert(0, get.ext_name)
        self.__write_logs("向网站[%s]添加扩展名排除[%s]" % (site, get.ext_name))
        self.__write_config()
        return public.returnMsg(False, '添加成功!');

    def get_global_total(self, get):
        self.__read_config()
        data = {}
        data['client'] = self.__get_file_json(
            self.__plugin_path + '/total/client.json')
        data['area'] = self.__get_file_json(
            self.__plugin_path + '/total/area.json')
        data['network'] = self.__get_file_json(
            self.__plugin_path + '/total/network.json')
        data['request'] = self.__get_file_json(
            self.__plugin_path + '/total/request.json')
        data['spider'] = self.__get_file_json(
            self.__plugin_path + '/total/spider.json')
        data['open'] = self.__config['open']
        return data

    def get_sites(self, get):
        # self._check_site()
        if os.path.exists('/www/server/apache'):
            if not os.path.exists('/usr/local/memcached/bin/memcached'):
                return public.returnMsg(False, '需要memcached,请先到【软件管理】页面安装!')
            if not os.path.exists('/var/run/memcached.pid'):
                return public.returnMsg(False, 'memcached未启动,请先启动!')
        # modc = self.__get_mod(get)
        # if not cache.get('bt_total'):  return modc
        result = {}
        data = []
        
        res = self.get_site_lists(get)
        if not res["status"]:
            return data
        site_lists = res["data"]
        for siteName in site_lists:
            tmp = {}
            tmp['total'] = self.__get_site_total(siteName)
            tmp['site_name'] = siteName
            data.append(tmp)
        data = sorted(data, key=lambda x: x['total']['request'], reverse=True)
        data = sorted(data, key=lambda x: x['total']['day_request'],
                      reverse=True)
        result['data'] = data
        result['open'] = self.get_config()['monitor']
        self.write_site_domains()
        return result

    def __get_mod(self, get):
        # filename = '/www/server/panel/plugin/bt_total/bt_total_init.py';
        # if os.path.exists(filename): os.remove(filename);
        if cache.get('bt_total'): return public.returnMsg(True, 'OK!');
        tu = '/proc/sys/net/ipv4/tcp_tw_reuse'
        if public.readFile(tu) != '1': public.writeFile(tu, '1');
        params = {}
        params['pid'] = '100000014';
        result = panelAuth().send_cloud('check_plugin_status', params)
        try:
            if not result['status']:
                if cache.get('bt_total'): cache.delete('bt_total')
                return result;
        except:
            pass;
        cache.set('bt_total', True)
        return result

    def get_history_data_dir(self):
        if self.history_data_dir is None:
            default_history_data_dir = os.path.join(self.__plugin_path, "logs")
            settings = self.get_site_settings("global")
            if "history_data_dir" in settings.keys():
                config_data_dir = settings["history_data_dir"]
            else:
                config_data_dir = default_history_data_dir
            self.history_data_dir = default_history_data_dir if not config_data_dir else config_data_dir
        return self.history_data_dir

    def get_data_dir(self):
        if self.data_dir is None:
            default_data_dir = os.path.join(self.__plugin_path, "logs")
            settings = self.get_site_settings("global")
            if "data_dir" in settings.keys():
                config_data_dir = settings["data_dir"]
            else:
                config_data_dir = default_data_dir
            self.data_dir = default_data_dir if not config_data_dir else config_data_dir
        return self.data_dir

    def get_log_db_path(self, site, db_name="logs.db", history=False):
        site = site.replace('_', '.')
        if not history:
            data_dir = self.get_data_dir()
            db_path = os.path.join(data_dir, site, db_name)
        else:
            data_dir = self.get_history_data_dir()
            db_name = "history_logs.db"
            db_path = os.path.join(data_dir, site, db_name)
        return db_path

    def get_realtime_request(self, site=None):
        """获取实时请求数"""
        res_data = []
        if site is not None:
            log_file = self.__plugin_path + "/logs/{}/req_sec.json".format(site)
            if not os.path.isfile(log_file):
                return res_data

            datetime_now = datetime.datetime.now()
            req_data = public.readFile(log_file)
            lines = req_data.split("\n")
            for line in lines:
                if not line: continue
                try:
                    _rt_req, _write_time = line.split(",")
                    datetime_log = datetime.datetime.fromtimestamp(
                        float(_write_time))
                    # print(datetime_log.strftime("%y%m%d %H:%M:%S"))
                    datetime_interval = datetime_now - datetime_log
                    # print("interval:", datetime_interval.seconds)
                    if datetime_interval.seconds < 3:
                        data = {"timestamp": _write_time, "req": int(_rt_req)}
                        res_data.append(data)

                except Exception as e:
                    print("Real-time data error:", str(e))
            if len(res_data) > 1:
                res_data.sort(key=lambda o: o["timestamp"], reverse=True)
        return res_data

    def get_realtime_traffic(self, site=None):
        """获取实时流量"""
        res_data = []
        if site is not None:
            flow_file = self.__plugin_path + "/logs/{}/flow_sec.json".format(
                site)
            if not os.path.isfile(flow_file):
                return res_data
            flow_data = public.readFile(flow_file)
            datetime_now = datetime.datetime.now()
            # print("Now:", datetime_now.strftime("%Y%m%d %H:%M:%S"))
            # print("Now:", datetime_now.timestamp())
            lines = flow_data.split("\n")
            for line in lines:
                if not line: continue
                try:
                    _flow, _write_time = line.split(",")
                    datetime_log = datetime.datetime.fromtimestamp(
                        float(_write_time))
                    datetime_interval = datetime_now - datetime_log
                    if datetime_interval.seconds < 3:
                        # print("flow interval by datetime:", datetime_interval.seconds)
                        # print(datetime_log.strftime("%Y%m%d %H:%M:%S"), _flow)
                        data = {"timestamp": _write_time, "flow": int(_flow)}
                        res_data.append(data)

                except Exception as e:
                    print("Real-time traffic error:", str(e))
            if len(res_data) > 1:
                res_data.sort(key=lambda o: o["timestamp"], reverse=True)
        return res_data

    def get_refresh_interval(self, site):
        global_config = self.get_site_settings("global")
        return global_config["refresh_interval"]

    def get_refresh_status(self, site):
        global_config = self.get_site_settings("global")
        return global_config["autorefresh"]

    def get_monitor_status(self, site):
        global_config = self.get_site_settings("global")
        if not global_config["monitor"]:
            return False
        config = self.get_site_settings(site)
        return config["monitor"]

    def init_site_db(self, site):
        """初始化数据库"""
        tm = total_migrate()
        data_dir = self.get_data_dir()
        tm.init_site_db(site, target_data_dir=data_dir)

    def init_ts(self, site):
        self.init_site_db(site)
        db_path = self.get_log_db_path(site)
        ts = tsqlite()
        ts.dbfile(db_path)
        return ts

    def get_site_overview_sum_data(self, site, start_date, end_date):
        """获取站点概览页的统计数据"""
        ts = self.init_ts(site)
        sum_data = {}
        default_fields = "req,pv,uv,ip,length,spider,s50x,s40x"
        if not ts:
            for field in default_fields.split(","):
                sum_data[field] = 0
            return sum_data
        # 统计数据
        s50x_fields = ",sum(status_500+status_501+status_502+status_503+status_504+status_505+status_506+status_507+status_509+status_510) as s50x"
        s40x_fields = ",sum(status_400+status_401+status_402+status_403+status_404+status_405+status_406+status_407+status_408+status_409+status_410+status_411+status_412+status_413+status_414+status_415+status_416+status_417+status_418+status_421+status_422+status_423+status_424+status_425+status_426+status_449+status_451) as s40x"
        total_fields = "sum(req) as req, sum(pv) as pv, sum(uv) as uv, sum(ip) as ip, sum(length) as length, sum(spider) as spider, sum(fake_spider) as fake_spider"
        total_fields += s50x_fields + s40x_fields
        ts.table("request_stat").field(total_fields)
        ts.where("time between ? and ?", (start_date, end_date))
        sum_data = ts.find()
        # print("sum data:")
        # print(sum_data)

        if type(sum_data) != dict:
            for field in default_fields.split(","):
                sum_data[field] = 0
            return sum_data

        for key, value in sum_data.items():
            if not value:
                sum_data[key] = 0

        return sum_data

    def get_overview_by_day(self, site, start_date, end_date, time_scale="hour",
                            target=None):
        """获取某一段时间的概览数据"""
        data = []
        sum_data = {}

        ts = self.init_ts(site)
        if not ts:
            return data, self.get_site_overview_sum_data(site, start_date,
                                                         end_date)

        if target is None:
            target = "pv"

        allow_target = ["pv", "uv", "ip", "req", "length", "spider", "s50x", "s40x"]
        if target in allow_target:
            # 绘图数据
            if time_scale == "hour":
                ts.table("request_stat").field("time," + target)
                ts.where("time between ? and ?", (start_date, end_date))
                ts.order("time")
            elif time_scale == "day":
                sum_fields = "sum(" + target + ") as " + target
                sum_fields = "time/100 as time1," + sum_fields
                ts.table("request_stat").groupby("time1").field(sum_fields)
                ts.where("time between ? and ?", (start_date, end_date))
                ts.order("time1")

            data = ts.select()
            if type(data) != list:
                data = []
            if time_scale == "day":
                for d in data:
                    d["time"] = d["time1"]
                    del d["time1"]

        sum_data = self.get_site_overview_sum_data(site, start_date, end_date)
        return data, sum_data

    def get_site_overview(self, get):
        try:
            ts = None
            site = self.__get_siteName(get.site)
            query_date = "today"
            if 'query_date' in get:
                query_date = get.query_date
            target = "pv"
            if 'target' in get:
                target = get.target
            time_scale = 'hour'
            if 'time_scale' in get:
                time_scale = get.time_scale
            compare = False
            if 'compare' in get:
                compare = True if get.compare.lower() == "true" else False
            compare_date = "yesterday"
            if compare:
                if 'compare_date' in get:
                    compare_date = get.compare_date
            request_time = None
            if 'request_data_time' in get:
                request_time = get.request_data_time

            # if request_time is not None:
            #     print("请求时间{}以后的数据。".format(request_time))

            self.flush_data(site)
            data = []
            sum_data = {}
            compare_data = []
            compare_sum_data = {}

            start_date, end_date = tool.get_query_date(query_date)
            # print("查询时间周期: {} - {}".format(start_date, end_date))
            if request_time is not None:
                data, sum_data = self.get_overview_by_day(
                    site, request_time, end_date,
                    time_scale=time_scale, target=target)
            else:
                data, sum_data = self.get_overview_by_day(
                    site, start_date, end_date,
                    time_scale=time_scale, target=target)

            if compare:
                compare_start_date, compare_end_date = tool.get_compare_date(
                    start_date, compare_date)
                # print("对比时间周期: {} - {}".format(compare_start_date, compare_end_date))
                compare_data, compare_sum_data = self.get_overview_by_day(
                    site, compare_start_date, compare_end_date,
                    time_scale=time_scale, target=target)

            realtime_req = self.get_realtime_request(site=site)
            realtime_traffic = self.get_realtime_traffic(site=site)

            request_time = tool.get_time_key()
            res_query_date = "{}-{}".format(start_date, end_date)
            res_compare_date = ""
            if compare:
                res_compare_date = "{}-{}".format(compare_start_date,
                                                  compare_end_date)

            migrate = self.get_migrate_status({})
            migrate_status = False
            if migrate["status"] == "completed":
                migrate_status = True

            online_data = self.get_online_ip_library()

            res_data = {
                "status": True,
                "query_date": res_query_date,
                "target": target,
                "time_scale": time_scale,
                "data": data,
                "sum_data": sum_data,
                "realtime_request": realtime_req,
                "realtime_traffic": realtime_traffic,
                "compare": compare,
                "compare_date": res_compare_date,
                "compare_data": compare_data,
                "compare_sum_data": compare_sum_data,
                "request_data_time": request_time,
                "migrated": migrate_status,
                "autorefesh": self.get_refresh_status(site),
                "refresh_interval": self.get_refresh_interval(site),
                "monitor": self.get_monitor_status(site),
                "online_data": online_data is not None
            }
            self.switch_site(get)
            return res_data
        except KeyError as e:
            return tool.returnMsg(
                False, 
                "REQUEST_INTERFACE_ERROR", 
                args=(tool.getMsg("INTERFACE_SITE_OVERVIEW"),str(e),)
            )

    def get_top_spiders(self, site, start_date, end_date, target, top):
        ts = self.init_ts(site)
        sum_fields = ""
        top = 10
        spiders = []
        if not ts:
            return []

        if not target or target == "top":
            table_name = "spider_stat"
            columns = ts.query("PRAGMA table_info([{}])".format(table_name))
            sum_fields = ""
            # 动态生成数据列
            for column in columns:
                client_name = column[1]
                if client_name == "time": continue
                if client_name.find("_flow")>0: continue
                if sum_fields:
                    sum_fields += ","
                sum_fields += "sum(" + client_name + ") as " + client_name

            ts.table("spider_stat").field(sum_fields)
            ts.where("time between ? and ?", (start_date, end_date))
            sum_data = ts.find()
            # print("sum data:", sum_data)
            top_columns = []
            # print(sorted(sum_data, key=lambda kv:(kv[1], kv[0]), reverse=True))
            if len(sum_data) and type(sum_data) != str:
                _columns = sorted(sum_data.items(),
                                  key=lambda kv: (kv[1], kv[0]),
                                  reverse=True)
                for i in range(len(_columns)):
                    if i == top: break
                    top_columns.append(_columns[i][0])
        else:
            if target.find(",") >= 0:
                top_columns = target.split(",")
            else:
                top_columns = [target]
        return top_columns

    def get_spider_by_day(self, get):
        """获取某一天的蜘蛛详细统计 """
        try:
            site = self.__get_siteName(get.site)
            query_date = "today"
            if "query_date" in get:
                query_date = get.query_date

            start_date, end_date = tool.get_query_date(query_date)
            db_path = self.get_log_db_path(site)
            if not os.path.isfile(db_path):
                return public.returnMsg(False, "蜘蛛统计数据为空!")
            ts = tsqlite()
            ts.dbfile(db_path)
            ts.table("spider_stat")
            ts.where("time between ? and ?", (start_date, end_date))
            data = ts.select()
            return data
        except Exception as e:
            return public.returnMsg(False, "获取蜘蛛统计明细出现错误！")

    def get_site_spider_stat_by_time_interval(self, site, start_date, end_date,
                                              time_scale="hour", target=None):
        """获取某一时间区间的蜘蛛统计数据
        :site 站点名
        :start_date 起始时间
        :end_date 终止时间
        :time_scale 时间刻度
        :target 绘图指标
        """
        data = []
        sum_data = {}

        db_path = self.get_log_db_path(site)
        if not os.path.isfile(db_path):
            return data, sum_data

        ts = tsqlite()
        ts.dbfile(db_path)
        new_target = ""
        top_columns = target
        top = len(top_columns)

        # 2. 根据统计数据查询图表数据
        if time_scale == "hour":
            fields = ",".join(top_columns)
            fields = "time," + fields
            ts.table("spider_stat").field(fields)
            ts.where("time between ? and ?", (start_date, end_date))
            data = ts.select()
        elif time_scale == "day":
            fields = ""
            for i, col in enumerate(top_columns):
                if i == top: break
                if fields:
                    fields += ","
                fields += "sum(" + col + ") as " + col
            # print("fields :", fields)
            # print("start:{}/end:{}".format(start_date, end_date))
            ts.table("spider_stat").field(fields)
            ts.where("time between ? and ?", (start_date, end_date))
            _data = ts.find()
            for column in top_columns:
                data.append({column: _data[column]})

        total_data = {}
        table_name = "spider_stat"
        columns = ts.query("PRAGMA table_info([{}])".format(table_name))
        sum_fields = ""
        # 动态生成数据列
        for column in columns:
            client_name = column[1]
            if client_name == "time": continue
            if client_name.find("_flow")>0: continue
            if sum_fields:
                sum_fields += "+"
            sum_fields += client_name
        total_field = "sum(" + sum_fields + ") as total"
        ts.table(table_name).field(total_field)
        ts.where("time between ? and ?", (start_date, end_date))
        total_res = ts.find()
        total_data["spider_total"] = total_res["total"]

        # 补充总请求数
        ts.table("request_stat").field("sum(req) as req, sum(fake_spider) as fake_spider")
        ts.where("time between ? and ?", (start_date, end_date))
        total_req = ts.find()
        if total_req:
            total_data["total_req"] = total_req["req"]
            total_data["fake_spider"] = total_req["fake_spider"]
        else:
            total_data["total_req"] = 0
            total_data["fake_spider"] = 0

        return data, total_data

    def get_spider_list(self, site, start_date, end_date, order="time",
                        desc=True, page_size=20, page=1):
        """获取蜘蛛统计列表数据"""

        list_data = []
        total_row = 0
        ts = self.init_ts(site)
        if not ts:
            return list_data, total_row

        sum_fields = ""
        table_name = "spider_stat"
        columns = ts.query("PRAGMA table_info([{}])".format(table_name))
        sum_fields = ""
        # 动态生成数据列
        for column in columns:
            client_name = column[1]
            if client_name == "time": continue;
            if sum_fields:
                sum_fields += ","
            sum_fields += "sum(" + client_name + ") as " + client_name

        # 列表数据查询
        list_fields = "time/100 as time1, " + sum_fields
        list_fields += ",sum(other) as other"
        ts.table("spider_stat").field(list_fields).groupby("time1")
        # ts.where("time between ? and ?", (start_date, end_date))
        if "time" == order:
            order = "time1"
        if desc:
            order += " desc"
        page_start = (page - 1) * page_size
        ts.order(order)
        list_data = ts.select()
        total_row = len(list_data)
        list_data = list_data[page_start:page_start + page_size]
        for d in list_data:
            d["time"] = d["time1"]
            del d["time1"]
        return list_data, total_row

    def get_spider_stat(self, get):
        try:
            site = self.__get_siteName(get.site)
            query_date = "today"
            if 'query_date' in get:
                query_date = get.query_date
            time_scale = 'hour'
            if 'time_scale' in get:
                time_scale = get.time_scale
            compare = False
            if 'compare' in get:
                compare = True if get.compare.lower() == "true" else False
            compare_date = "yesterday"
            if compare:
                if 'compare_date' in get:
                    compare_date = get.compare_date
            target = "top"
            if "target" in get:
                target = get.target
            request_time = None
            if 'request_data_time' in get:
                request_time = get.request_data_time
            page = 1
            if "page" in get:
                page = int(get.page)
            page_size = 20
            if "page_size" in get:
                page_size = int(get.page_size)
            orderby = "time"
            if "orderby" in get:
                orderby = get.orderby
            desc = True
            if "desc" in get:
                desc = True if get.desc.lower() == "true" else False
            # if request_time is not None:
            #     print("请求时间{}以后的数据。".format(request_time))

            data = []
            sum_data = {}
            compare_data = []
            compare_sum_data = {}
            list_data = []
            total_row = 0

            start_date, end_date = tool.get_query_date(query_date)
            # print("查询时间周期: {} - {}".format(start_date, end_date))

            db_path = self.get_log_db_path(site)

            request_time = tool.get_time_key()
            res_query_date = "{}-{}".format(start_date, end_date)
            res_compare_date = ""
            if not os.path.isfile(db_path):
                # print("监控数据为空。")
                return {
                    "status": True,
                    "query_date": res_query_date,
                    "data": data,
                    "sum_data": sum_data,
                    "compare": compare,
                    "compare_date": res_compare_date,
                    "compare_data": compare_data,
                    "compare_sum_data": compare_sum_data,
                    "request_data_time": request_time,
                    "page": page,
                    "page_size": page_size,
                    "total_row": total_row,
                    "list_data": list_data,
                    "autorefesh": self.get_refresh_status(site),
                    "monitor": self.get_monitor_status(site)
                }

            self.flush_data(site)
            top = 5
            # self.log("site:" + site)
            top_columns = self.get_top_spiders(site, start_date, end_date,
                                               target, top)
            if request_time is not None:
                # 默认top的情况下，每次重新请求
                if target and target != "top":
                    data, sum_data = self.get_site_spider_stat_by_time_interval(
                        site, request_time, end_date, time_scale=time_scale,
                        target=top_columns)
                else:
                    data, sum_data = self.get_site_spider_stat_by_time_interval(
                        site, start_date, end_date, time_scale=time_scale,
                        target=top_columns)
                list_data, total_row = self.get_spider_list(site, request_time,
                                                            end_date,
                                                            order=orderby,
                                                            desc=desc,
                                                            page_size=page_size,
                                                            page=page)
            else:
                data, sum_data = self.get_site_spider_stat_by_time_interval(
                    site, start_date, end_date, time_scale=time_scale,
                    target=top_columns)
                list_data, total_row = self.get_spider_list(site, start_date,
                                                            end_date,
                                                            order=orderby,
                                                            desc=desc,
                                                            page_size=page_size,
                                                            page=page)

            if compare:
                compare_start_date, compare_end_date = tool.get_compare_date(
                    start_date, compare_date)
                # print("对比时间周期: {} - {}".format(compare_start_date, compare_end_date))
                compare_data, compare_sum_data = self.get_site_spider_stat_by_time_interval(
                    site, compare_start_date, compare_end_date,
                    time_scale=time_scale, target=top_columns)
                res_compare_date = "{}-{}".format(compare_start_date,
                                                  compare_end_date)

            res_data = {
                "status": True,
                "query_date": res_query_date,
                "data": data,
                "sum_data": sum_data,
                "compare": compare,
                "compare_date": res_compare_date,
                "compare_data": compare_data,
                "compare_sum_data": compare_sum_data,
                "request_data_time": request_time,
                "page": page,
                "page_size": page_size,
                "total_row": total_row,
                "list_data": list_data,
                "autorefesh": self.get_refresh_status(site),
                "monitor": self.get_monitor_status(site)
            }
            self.switch_site(get)
            return res_data
        except Exception as e:
            return tool.returnMsg(
                False, 
                "REQUEST_INTERFACE_ERROR",
                args=(
                    tool.getMsg("INTERFACE_SPIDER_STAT"),
                    str(e),
                )
            )

    def update_spiders_from_cloud(self, get=None):
        """从云端更新蜘蛛IP库
    
        Returns:
            bool: true/false 是否更新成功
        """
        try:
            userInfo = json.loads(public.ReadFile('/www/server/panel/data/userInfo.json'))
            data22 = {"access_key": userInfo['access_key'], "uid": userInfo['uid']}
            url = 'http://www.bt.cn/api/bt_waf/getSpiders'
            data_list = json.loads(public.httpPost(url, data22, timeout=3))
            has_content = False
            # print("蜘蛛种类: {}".format(len(data_list)))
            # print(data_list)
            if data_list:
                spiders_dir = "/www/server/total/xspiders"
                if not os.path.exists(spiders_dir):
                    os.mkdir(spiders_dir)
                for i22 in data_list:
                    try:
                        path = "%s/%s.json" % (spiders_dir, i22)
                        if os.path.exists(path):
                            ret = json.loads(public.ReadFile(path))
                            localhost_json = list(set(ret).union(data_list[i22]))
                        else:
                            localhost_json = data_list[i22]
                        print("开始写入{}蜘蛛库...".format(i22))
                        public.WriteFile(path, json.dumps(localhost_json))
                        has_content = True
                    except:
                        pass
                        
                now = time.time()
                time_log = "%s/latest_update.log" % spiders_dir
                public.WriteFile(time_log, str(now))

                public.ExecShell("chown -R www:www {}".format(spiders_dir))
            if has_content:
                return public.returnMsg(True, "更新成功！")
            return public.returnMsg(True, "未更新数据。")
        except Exception as e:
            return public.returnMsg(False, "更新失败:" + str(e))

    def get_site_client_stat_by_time_interval(self, site, start_date, end_date,
                                              time_scale="hour", target=None):
        """获取某一时间区间的客户端统计数据
        :site 站点名
        :start_date 起始时间
        :end_date 终止时间
        :time_scale 时间刻度
        :target 绘图指标
        """
        data = []
        sum_data = {}

        db_path = self.get_log_db_path(site)
        if not os.path.isfile(db_path):
            return data, sum_data

        ts = tsqlite()
        ts.dbfile(db_path)
        new_target = ""
        top_columns = target
        top = len(top_columns)
        table_name = "client_stat"

        # 2. 根据统计数据查询图表数据
        if time_scale == "hour":
            fields = ",".join(top_columns)
            fields = "time," + fields
            ts.table(table_name).field(fields)
            ts.where("time between ? and ?", (start_date, end_date))
            data = ts.select()
        elif time_scale == "day":
            fields = ""
            for i, col in enumerate(top_columns):
                if i == top: break
                if fields:
                    fields += ","
                fields += "sum(" + col + ") as " + col
            ts.table(table_name).field(fields)
            ts.where("time between ? and ?", (start_date, end_date))
            _data = ts.find()
            for column in top_columns:
                data.append({column: _data[column]})

        columns = ts.query("PRAGMA table_info([{}])".format(table_name))
        total_data = {}

        pc_clients = ["firefox","msie","qh360","theworld","tt","maxthon","opera","qq","uc","safari","chrome","metasr","pc2345","edeg"]
        mobile_clients = ["android", "iphone"]

        total_field = ""
        pc_field = ""
        mobile_field = ""
        for column in columns:
            client_name = column[1]
            if client_name == "time": continue
            for pc in pc_clients:
                if client_name == pc:
                    if pc_field:
                        pc_field += "+"
                    pc_field += client_name
                    break

            # for mobile in mobile_clients:
            #     if client_name == mobile["column"]:
            #         if mobile_field:
            #             mobile_field += "+"
            #         mobile_field += client_name

        pc_field = "sum(" + pc_field + ") as pc"
        mobile_field = "sum(mobile) as mobile"
        ts.table(table_name).field(",".join([pc_field, mobile_field]))
        ts.where("time between ? and ?", (start_date, end_date))
        total_res = ts.find()
        total_data["total_pc"] = total_res["pc"]
        total_data["total_mobile"] = total_res["mobile"]

        # 补充总请求数
        ts.table("request_stat").field("sum(req) as req")
        ts.where("time between ? and ?", (start_date, end_date))
        total_req = ts.find()
        if total_req:
            total_data["total_req"] = total_req["req"]
        else:
            total_data["total_req"] = 0

        return data, total_data

    def get_client_list(self, ts, site, start_date, end_date, order="time",
                        desc=False, page_size=20, page=1):
        """获取客户端统计列表数据"""

        if not ts:
            ts = tsqlite()
            db_path = self.get_log_db_path(site)
            ts.dbfile(db_path)

        table_name = "client_stat"
        columns = ts.query("PRAGMA table_info([{}])".format(table_name))
        sum_fields = ""
        # 动态生成数据列
        for column in columns:
            client_name = column[1]
            if client_name == "time": continue
            if client_name == "mobile": continue
            if sum_fields:
                sum_fields += ","
            sum_fields += "sum(" + client_name + ") as " + client_name

        # 列表数据查询
        list_fields = "time/100 as time1, " + sum_fields
        ts.table(table_name).field(list_fields).groupby("time1")
        # ts.where("time between ? and ?", (start_date, end_date))
        if order == "time":
            order = "time1"
        if desc:
            order += " desc"
        ts.order(order)
        _data = ts.select()
        other_clients = ["metasr", "theworld", "tt", "maxthon", "opera", "qq",
                         "uc", "pc2345", "other", "linux"]
        list_data = []
        total_row = len(_data)
        page_start = (page - 1) * page_size
        _data = _data[page_start:page_start + page_size]
        for client_data in _data:
            tmp = {}
            other = {}
            for key, value in client_data.items():
                if key in other_clients:
                    other[key] = value
                else:
                    if key == "time1":
                        tmp["time"] = value
                    else:
                        tmp[key] = value
            tmp.update({"other": other})
            list_data.append(tmp)
        return list_data, total_row

    def get_top_clients(self, db, start_date, end_date, top=3):
        ts = db
        sum_fields = ""
        clients = []
        table_name = "client_stat"
        columns = ts.query("PRAGMA table_info([{}])".format(table_name))
        # print("columns:", str(columns))
        # 动态生成数据列
        for column in columns:
            client_name = column[1]
            if client_name == "time": continue
            if client_name == "mobile": continue
            if sum_fields:
                sum_fields += ","
            sum_fields += "sum(" + client_name + ") as " + client_name

        ts.table(table_name).field(sum_fields)
        ts.where("time>=? and time<=?", (start_date, end_date))
        sum_data = ts.find()
        top_columns = []
        # print(sorted(sum_data, key=lambda kv:(kv[1], kv[0]), reverse=True))
        if len(sum_data):
            _columns = sorted(sum_data.items(), key=lambda kv: (kv[1], kv[0]),
                              reverse=True)
            for i in range(len(_columns)):
                if i == top: break
                top_columns.append(_columns[i][0])
        return top_columns

    def get_client_stat(self, get, flush=True):
        try:
            ts = None
            site = self.__get_siteName(get.site)
            query_date = "today"
            if 'query_date' in get:
                query_date = get.query_date
            time_scale = 'day'
            if 'time_scale' in get:
                time_scale = get.time_scale
            compare = False
            if 'compare' in get:
                compare = True if get.compare.lower() == "true" else False
            compare_date = "yesterday"
            if compare:
                if 'compare_date' in get:
                    compare_date = get.compare_date
            target = "top"
            if "target" in get:
                target = get.target
            request_time = None
            if 'request_data_time' in get:
                request_time = get.request_data_time
            page = 1
            if "page" in get:
                page = int(get.page)
            page_size = 20
            if "page_size" in get:
                page_size = int(get.page_size)
            orderby = "time"
            if "orderby" in get:
                orderby = get.orderby
            desc = True
            if "desc" in get:
                desc = True if get.desc.lower() == "true" else False

            data = []
            sum_data = {}
            compare_data = []
            compare_sum_data = {}
            list_data = []
            total_row = 0

            start_date, end_date = tool.get_query_date(query_date)
            # print("查询时间周期: {} - {}".format(start_date, end_date))

            res_query_date = "{}-{}".format(start_date, end_date)
            db_path = self.get_log_db_path(site)
            if not os.path.isfile(db_path):
                res_data = {
                    "status": True,
                    "query_date": res_query_date,
                    "data": data,
                    "sum_data": sum_data,
                    "compare": compare,
                    "compare_date": res_query_date,
                    "compare_data": compare_data,
                    "compare_sum_data": compare_sum_data,
                    "request_data_time": request_time,
                    "page": page,
                    "page_size": page_size,
                    "total_row": total_row,
                    "list_data": list_data,
                    "autorefesh": self.get_refresh_status(site),
                    "monitor": self.get_monitor_status(site)
                }
                return res_data

            if flush:
                self.flush_data(site)
            ts = tsqlite()
            ts.dbfile(db_path)

            top_columns = []
            top = 10
            if target == "top":
                top_columns = self.get_top_clients(ts, start_date, end_date,
                                                   top)
            else:
                if target.find(",") >= 0:
                    top_columns = target.split(",")
                else:
                    top_columns = [target]

            if request_time is not None:
                # 默认top的情况下，每次重新请求
                if target and target != "top":
                    data, sum_data = self.get_site_client_stat_by_time_interval(
                        site, request_time, end_date, time_scale=time_scale,
                        target=top_columns)
                else:
                    data, sum_data = self.get_site_client_stat_by_time_interval(
                        site, start_date, end_date, time_scale=time_scale,
                        target=top_columns)
                list_data, total_row = self.get_client_list(ts, site,
                                                            request_time,
                                                            end_date,
                                                            order=orderby,
                                                            desc=desc,
                                                            page_size=page_size,
                                                            page=page)
            else:
                data, sum_data = self.get_site_client_stat_by_time_interval(
                    site, start_date, end_date, time_scale=time_scale,
                    target=top_columns)
                list_data, total_row = self.get_client_list(ts, site,
                                                            start_date,
                                                            end_date,
                                                            order=orderby,
                                                            desc=desc,
                                                            page_size=page_size,
                                                            page=page)

            if compare:
                compare_start_date, compare_end_date = tool.get_compare_date(
                    start_date, compare_date)
                # print("对比时间周期: {} - {}".format(compare_start_date, compare_end_date))
                compare_data, compare_sum_data = self.get_site_client_stat_by_time_interval(
                    site, compare_start_date, compare_end_date,
                    time_scale=time_scale, target=top_columns)

            request_time = tool.get_time_key()
            res_query_date = "{}-{}".format(start_date, end_date)
            res_compare_date = ""
            if compare:
                res_compare_date = "{}-{}".format(compare_start_date,
                                                  compare_end_date)

            res_data = {
                "status": True,
                "query_date": res_query_date,
                "data": data,
                "sum_data": sum_data,
                "target": target,
                "compare": compare,
                "compare_date": res_compare_date,
                "compare_data": compare_data,
                "compare_sum_data": compare_sum_data,
                "request_data_time": request_time,
                "page": page,
                "page_size": page_size,
                "total_row": total_row,
                "list_data": list_data,
                "autorefesh": self.get_refresh_status(site),
                "monitor": self.get_monitor_status(site)
            }
            return res_data
        except Exception as e:
            return tool.returnMsg(
                False, 
                "REQUEST_INTERFACE_ERROR",
                args=(
                    tool.getMsg("INTERFACE_CLIENT_STAT"),
                    str(e),
                )
            )

    def get_error_code(self, get):
        error_code = [
            "all", "50x", "40x", "500", "501", "502", "503", "404"
        ]
        return {"status_codes": error_code}

    def get_site_error_sql(self, start_date, end_date, status_code, *args, **kwargs):
        if True:
            status_code_50x = [500, 501, 502, 503, 504, 505, 506, 507, 509, 510]
            status_code_40x = [400, 401, 402, 403, 404, 405, 406, 407, 408, 409,
                               410, 411, 412, 413, 414, 415, 416, 417, 418, 421, 
                               422, 423, 424, 425, 426, 449, 451]
            if status_code == "50x":
                status_codes = ",".join([str(s) for s in status_code_50x])
            elif status_code == "40x":
                status_codes = ",".join([str(s) for s in status_code_40x])
            elif status_code == "all":
                status_codes = ",".join(
                    [str(s) for s in (status_code_50x + status_code_40x)])
            else:
                status_codes = status_code
            # ts.table("site_logs").field(fields)
            where_sql = " where time >={} and time <={}".format(start_date, end_date)
            where_sql += " and status_code in ({})".format(status_codes)
            conditions = kwargs
            if "spider" in conditions.keys():
                spider = conditions["spider"].lower()
                if spider == "only_spider":
                    where_sql += " and is_spider=1"
                if spider == "no_spider":
                    where_sql += " and is_spider=0"

            select_sql = "select {} from site_logs" + where_sql
            # print(select_sql)
            return select_sql

    def get_site_error_logs_total_old(self, get):
        try:
            site = get.site
            conditions = {}
            query_date = "today"
            if 'query_date' in get:
                query_date = get.query_date
            status_code = "all"
            if "status_code" in get:
                status_code = get.status_code
            if "spider" in get:
                spider = get.spider
                if spider:
                    conditions["spider"] = spider

            db_path = None
            if "db_path" in get:
                db_path = get.db_path
            if not db_path:
                db_path = self.get_log_db_path(site)
            check_total = False
            if "check_total" in get or hasattr(get, "check_total"):
                check_total = get.check_total
            page = 1
            if "page" in get:
                page = int(get.page)
            page_size = 100
            if "page_size" in get:
                page_size = int(get.page_size)

            db_path = None
            if "db_path" in get:
                db_path = get.db_path
            if not db_path:
                db_path = self.get_log_db_path(site)
            
            if not os.path.exists(db_path):
                return {"total_row": 0}

            ts = tsqlite()
            ts.dbfile(db_path)

            start_date, end_date = tool.get_query_timestamp(query_date)
            select_sql = self.get_site_error_sql(start_date, end_date, status_code, **conditions)
            total_sql = select_sql.format("count(*)")

            cache_key = public.md5(db_path+total_sql)
            last_cache_key = public.md5("LAST_"+db_path+total_sql)
            except_total = page * page_size
            last_cache_row = cache.get(last_cache_key)

            if check_total and last_cache_row:
                if except_total < last_cache_row:
                    return {"total_row": last_cache_row}
            cache_row = cache.get(cache_key)
            if cache_row:
                return {"total_row": cache_row}
            total_res = ts.query(total_sql)
            total_row = int(total_res[0][0])
            cache.set(cache_key, total_row, 10)
            cache.set(last_cache_key, total_row, 86400)
            ts.close()
            return {"total_row":total_row}
        except:
            return {"total_row":0}
    
    def get_site_error_logs_total(self, get):
        site = get.site
        query_date = "today"
        if 'query_date' in get:
            query_date = get.query_date
        query_array = tool.split_query_date(query_date)
        # print("site error total/query array:")
        # print(query_array)
        if len(query_array) == 1:
            if "today" in query_array:
                get.db_path = self.get_log_db_path(site)
            else:
                get.db_path = self.get_log_db_path(site, history=True)
            return self.get_site_error_logs_total_old(get)
        
        get.query_date = "today"
        query_array.remove("today")
        get.db_path = self.get_log_db_path(site)
        sel_res = self.get_site_error_logs_total_old(get)
        hot_rows = 0
        if "total_row" in sel_res:
            hot_rows = sel_res["total_row"]

        get.query_date = query_array[0]
        get.db_path = self.get_log_db_path(site, history=True)
        sel_res = self.get_site_error_logs_total_old(get)
        his_rows = 0
        if "total_row" in sel_res:
            his_rows = sel_res["total_row"]
        
        return {
            "total_row": hot_rows + his_rows
        }

    def get_site_error_logs_old(self, get):
        try:
            ts = None
            site = get.site
            conditions = {}
            query_date = "today"
            if 'query_date' in get:
                query_date = get.query_date
            status_code = "all"
            if "status_code" in get:
                status_code = get.status_code
            if "spider" in get:
                spider = get.spider
                if spider:
                    conditions["spider"] = spider

            page = 1
            if "page" in get:
                page = int(get.page)
            page_size = 20
            if "page_size" in get:
                page_size = int(get.page_size)
            orderby = "time"
            if "orderby" in get:
                orderby = get.orderby
            desc = True
            if "desc" in get:
                desc = True if get.desc.lower() == "true" else False
            no_total = False
            if "no_total_rows" in get:
                no_total = True if get.no_total_rows.lower() == "true" else False
            fields = "all"
            if "fields" in get:
                fields = get.fields
            db_path = None
            if "db_path" in get:
                db_path = get.db_path
            if not db_path:
                db_path = self.get_log_db_path(site)
            offset = 0
            if "offset" in get:
                offset = int(get.offset)

            list_data = []
            total_row = 0

            start_date, end_date = tool.get_query_timestamp(query_date)
            res_query_date = "{}-{}".format(start_date, end_date)
            if not os.path.isfile(db_path):
                res_data = {
                    "status": True,
                    "query_date": res_query_date,
                    "page": page,
                    "page_size": page_size,
                    "total_row": total_row,
                    "list_data": list_data,
                    "load_ip_info": False
                }
                return res_data

            self.flush_data(site)

            ts = tsqlite()
            ts.dbfile(db_path)

            load_ip_info = self.get_online_ip_library() is not None
            select_sql = self.get_site_error_sql(start_date, end_date, status_code, **conditions)

            total_row = 0
            if not no_total:
                total_sql = select_sql.format("count(*)")
                total_res = ts.query(total_sql)
                total_row = int(total_res[0][0])

            if fields == "all":
                fields = "time, ip, method, domain, status_code, protocol, uri, user_agent, body_length, referer, request_time, is_spider, request_headers, ip_list"
            select_data_sql = select_sql.format(fields)

            if orderby:
                select_data_sql += " order by " + orderby
            if desc:
                select_data_sql += " desc"
            
            page_start = (page - 1) * page_size
            # select_data_sql += " limit {},{}".format(str(page_start), str(page_size))
            select_data_sql += " limit {}".format(str(page_size))
            select_data_sql += " offset " + str(page_start+offset)
            # print("select error sql:")
            # print(select_data_sql)

            data = ts.query(select_data_sql)

            # select_end = datetime.datetime.now()
            # diff = select_end-select_start
            # diff_gmtime = time.gmtime(diff.total_seconds())
            # strtime = time.strftime("%H:%M:%S", diff_gmtime)
            # str_msec = '.' + str(diff)[-6:]
            # msec = '%.3f' % float(str_msec)
            # msec = msec[1:]
            # print("查询耗时:{}s".format(strtime+str(msec)))
            
            _columns = [column.strip() for column in fields.split(",")]
            error_count = {}
            for row in data:
                i = 0
                tmp1 = {}
                for column in _columns:
                    val = row[i]
                    if column == "status_code":
                        if val not in error_count:
                            error_count[val] = 1
                        else:
                            error_count[val] += 1
                    tmp1[column] = row[i]
                    i += 1
                list_data.append(tmp1)
                del (tmp1)

            res_data = {
                "status": True,
                "query_date": res_query_date,
                "page": page,
                "page_size": page_size,
                "total_row": total_row,
                "list_data": list_data,
                "total_data": error_count,
                "load_ip_info": load_ip_info
            }
            res_data.update(self.get_error_code(None))
            self.switch_site(get)
            return res_data
        except KeyError as e:
            return tool.returnMsg(
                False, 
                "REQUEST_INTERFACE_ERROR",
                args=(
                    tool.getMsg("INTERFACE_ERROR_LOGS"),
                    str(e),
                )
            )
    
    def get_site_error_logs(self, get):
        try:
            site = get.site
            query_date = "today"
            if 'query_date' in get:
                query_date = get.query_date
            query_array = tool.split_query_date(query_date)

            if len(query_array) == 1:
                if "today" in query_array:
                    get.db_path = self.get_log_db_path(site)
                else:
                    get.db_path = self.get_log_db_path(site, history=True)
                return self.get_site_error_logs_old(get)

            # print("合并查询:")
            # print(query_array)
            cur_page = 1
            if "page" in get:
                cur_page = int(get.page)

            page_size = 20
            if "page_size" in get:
                page_size = int(get.page_size)

            if "no_total_rows" in get:
                no_total = True if get.no_total_rows.lower() == "true" else False

            hot_data = []
            hot_res = {}
            # 热数据
            get.query_date = "today"
            get.check_total = True
            query_array.remove("today")
            get.db_path = self.get_log_db_path(site)
            hot_rows = self.get_site_error_logs_total(get)["total_row"]
            if cur_page * page_size <= hot_rows:
                return self.get_site_error_logs_old(get)
            else:
                hot_res = self.get_site_error_logs_old(get)
                if hot_res["status"]:
                    hot_data = hot_res["list_data"]
                else:
                    return hot_res

            # print("热数据:")
            # print(hot_data)
            # 历史数据
            get.check_total = False
            get.query_date = query_array[0]
            rows = cur_page * page_size
            offset = hot_rows % page_size 
            diff = rows - hot_rows
            his_page = diff//page_size
            his_page_size = page_size
            if diff%page_size>0:
                his_page += 1
            if his_page == 1:  # 中转页
                his_page_size = page_size - offset
                offset = 0
                get.page = 1
            if his_page > 1:
                offset = page_size - offset
                get.page = his_page - 1 
            get.offset = offset
            get.page_size = his_page_size
            get.query_date = query_array[0]
            get.db_path = self.get_log_db_path(site, history=True)
            res = self.get_site_error_logs_old(get)
            if res["status"]:
                second_data = res["list_data"]
                hot_res["list_data"] = hot_data + second_data
            else:
                if hot_data:
                    return hot_res
            self.switch_site(get)
            return hot_res
        except KeyError as e:
            return tool.returnMsg(
                False, 
                "REQUEST_INTERFACE_ERROR",
                args=(
                    tool.getMsg("INTERFACE_LOGS"),
                    str(e),
                )
            )

    def get_site_logs_sql(self, conditions):
        start_date = conditions["start_date"]
        end_date = conditions["end_date"]
        where_sql = " where time >= {} and time <= {}".format(start_date, end_date)
        if "status_code" in conditions.keys():
            status_code = conditions["status_code"]
            if status_code != "all":
                where_sql += " and status_code={}".format(status_code)
        if "method" in conditions.keys():
            method = conditions["method"]
            if method != "all":
                where_sql += " and method='{}'".format(method)
        search_url = ""
        if "search_url" in conditions.keys():
            search_url = conditions["search_url"]
        if "uri" in conditions.keys():
            search_url = conditions["uri"]
        if search_url:
            if search_url.find(",") < 0:
                where_sql += " and uri like '%{}%'".format(search_url)
            else:
                _sql = ""
                for url in search_url.split(","):
                    url = url.strip()
                    if _sql:
                        _sql += " or "
                    _sql += "uri like '%{}%'".format(url)
                where_sql += " and " + _sql
        if "spider" in conditions.keys():
            spider = conditions["spider"].lower()
            if spider == "only_spider":
                where_sql += " and is_spider>=1"
            elif spider == "no_spider":
                where_sql += " and is_spider=0"
            elif spider == "fake_spider":
                where_sql += " and is_spider=77"
            elif type(spider) == str:
                is_num = False
                try:
                    int(spider)
                    is_num = True
                except:
                    pass
                if not is_num:
                    spider_table = {
                    "baidu":1,
                    "bing":2,
                    "qh360" : 3,
                    "google" : 4,
                    "bytes" : 5,
                    "sogou" : 6,
                    "youdao" : 7,
                    "soso" : 8,
                    "dnspod" : 9,
                    "yandex" : 10,
                    "yisou" : 11,
                    "other" : 12
                    }
                    if spider in spider_table.keys():
                        where_sql += " and is_spider=" +str(spider_table[spider])
                else:
                    where_sql += " and is_spider=" + str(spider)

        if "ip" in conditions.keys():
            ip = conditions["ip"].strip()
            if ip:
                ip = ip.replace("，", ",")
                if ip.find(",") > 0:
                    ip = ",".join(["'"+ip.strip()+"'" for ip in ip.split(",")])
                    where_sql += " and ip in (" + ip + ")"
                elif ip.find("*") >= 0:
                    ip = ip.replace("*", "%")
                    where_sql += " and (ip like \"" + ip + "\" or ip_list like \"" + ip + "\")"
                else:
                    where_sql += " and (ip=\"" + ip + "\" or ip_list like \"%" + ip + "%\")"

        if "domain" in conditions.keys():
            domain = conditions["domain"].strip()
            if domain:
                where_sql += " and domain='" + domain +"'"
        
        if "user_agent" in conditions.keys():
            user_agent = conditions["user_agent"].strip()
            if user_agent:
                where_sql += " and user_agent like '%" + user_agent +"%'"
        
        if "referer" in conditions.keys():
            referer = conditions["referer"].strip()
            if referer:
                where_sql += " and referer like '%" + referer + "%'"
            
        select_sql = "select {} from site_logs" + where_sql
        return select_sql

    def get_site_logs_total_old(self, get):
        try:
            site = get.site
            conditions = {}
            query_date = "today"
            if 'query_date' in get:
                query_date = get.query_date
            status_code = "all"
            if "status_code" in get:
                status_code = get.status_code
                conditions["status_code"] = status_code
            if "method" in get:
                method = get.method
                conditions["method"] = method
            if "spider" in get:
                spider = get.spider
                if spider:
                    conditions["spider"] = spider
            filter_type = "ip"
            if "filter_type" in get:
                allow_filters = ["ip", "domain", "uri", "user_agent", "referer"]
                _filter_type = get.filter_type
                if _filter_type in allow_filters:
                    filter_type = _filter_type
                    if "filter_value" in get:
                        conditions[filter_type] = get.filter_value.strip()
            if "ip" in get:
                conditions["ip"] = get.ip
            if "domain" in get:
                conditions["domain"] = get.domain
            if "search_url" in get:
                conditions["search_url"] = get.search_url
            if "user_agent" in get:
                conditions["user_agent"] = get.user_agent
            if "referer" in get:
                conditions["referer"] = get.referer
            
            check_total = False
            if "check_total" in get or hasattr(get, "check_total"):
                check_total = get.check_total

            page = 1
            if "page" in get:
                page = int(get.page)
            page_size = 100
            if "page_size" in get:
                page_size = int(get.page_size)

            db_path = None
            if "db_path" in get:
                db_path = get.db_path
            if not db_path:
                db_path = self.get_log_db_path(site)
            
            if not os.path.exists(db_path):
                return {"total_row": 0}

            ts = tsqlite()
            ts.dbfile(db_path)

            start_date, end_date = tool.get_query_timestamp(query_date)
            conditions.update({
                "start_date": start_date,
                "end_date": end_date
            })
            select_sql = self.get_site_logs_sql(conditions)
            total_sql = select_sql.format("count(*)")

            cache_key = public.md5(db_path+total_sql)
            last_cache_key = public.md5("LAST_"+db_path+total_sql)
            except_total = page * page_size
            last_cache_row = cache.get(last_cache_key)
            # print("check total: {}".format(check_total))
            # print("{} last cache row:".format(get.query_date))
            # print(last_cache_row)
            # check_total 粗略判断历史数据是否大于预期数据量
            if check_total and last_cache_row:
                # print("期望数据条数: {}".format(except_total))
                if except_total < last_cache_row:
                    # print("check total: {}".format(last_cache_row))
                    # print("get total row by last cache: {}".format(last_cache_row))
                    return {"total_row": last_cache_row}

            cache_row = cache.get(cache_key)
            if cache_row:
                # print("get total row by cache")
                return {"total_row":cache_row}
            # print("select sql:")
            # print(select_sql)
            total_res = ts.query(total_sql)
            total_row = int(total_res[0][0])
            # print("query tota row:")
            # print(total_row)
            cache.set(cache_key, total_row, 10)
            cache.set(last_cache_key, total_row, 86400)
            ts.close()
            return {"total_row":total_row}
        except Exception as e:
            print("get logs total error:")
            print(e)
            return {"total_row":0}
            
    def get_site_logs_total(self, get):
        site = get.site
        query_date = "today"
        if 'query_date' in get:
            query_date = get.query_date
        query_array = tool.split_query_date(query_date)
        if len(query_array) == 1:
            if "today" in query_array:
                get.db_path = self.get_log_db_path(site)
            else:
                get.db_path = self.get_log_db_path(site, history=True) 
            return self.get_site_logs_total_old(get)
        
        get.query_date = "today"
        query_array.remove("today")
        get.db_path = self.get_log_db_path(site)
        sel_res = self.get_site_logs_total_old(get)
        # print("today logs total:")
        # print(sel_res)
        hot_rows = 0
        if "total_row" in sel_res:
            hot_rows = sel_res["total_row"]

        get.query_date = query_array[0]
        get.db_path = self.get_log_db_path(site, history=True) 
        sel_res = self.get_site_logs_total_old(get)
        # print("history logs total:")
        # print(sel_res)
        his_rows = 0
        if "total_row" in sel_res:
            his_rows = sel_res["total_row"]
        
        return {
            "total_row": hot_rows + his_rows
        }


    def get_site_logs_old(self, get):
        try:
            ts = None
            conditions = {}
            site = get.site
            query_date = "today"
            if 'query_date' in get:
                query_date = get.query_date
            method = "all"
            if "method" in get:
                method = get.method
                conditions["method"] = method
            status_code = "all"
            if "status_code" in get:
                status_code = get.status_code
                conditions["status_code"] = status_code
            
            if "spider" in get:
                spider = get.spider
                if spider:
                    conditions["spider"] = spider
            filter_type = "ip"
            if "filter_type" in get:
                allow_filters = ["ip", "domain", "uri", "user_agent", "referer"]
                _filter_type = get.filter_type
                if _filter_type in allow_filters:
                    filter_type = _filter_type
                    if "filter_value" in get:
                        conditions[filter_type] = get.filter_value.strip()
            if "ip" in get:
                conditions["ip"] = get.ip
            if "domain" in get:
                conditions["domain"] = get.domain
            if "search_url" in get:
                conditions["search_url"] = get.search_url
            if "user_agent" in get:
                conditions["user_agent"] = get.user_agent
            if "referer" in get:
                conditions["referer"] = get.referer            
            page = 1
            if "page" in get:
                page = int(get.page)
            page_size = 20
            if "page_size" in get:
                page_size = int(get.page_size)
            orderby = "time"
            if "orderby" in get:
                orderby = get.orderby
            desc = True
            if "desc" in get:
                desc = True if get.desc.lower() == "true" else False
            no_total = False
            if "no_total_rows" in get:
                no_total = True if get.no_total_rows.lower() == "true" else False
            fields = "all"
            if "fields" in get:
                fields = get.fields
            db_path = self.get_log_db_path(site)
            if "db_path" in get:
                db_path = get.db_path
            offset = 0
            if "offset" in get:
                offset = int(get.offset)

            list_data = []
            total_row = 0

            start_date, end_date = tool.get_query_timestamp(query_date)
            # print("start date:"+str(start_date))
            # print("end date:"+str(end_date))
            # self.log("查询日志时间周期2: {} - {}".format(start_date, end_date))

            res_query_date = "{}-{}".format(start_date, end_date)
            if not os.path.isfile(db_path):
                res_data = {
                    "status": True,
                    "query_date": res_query_date,
                    "page": page,
                    "page_size": page_size,
                    "total_row": total_row,
                    "list_data": list_data,
                    "filter_type": filter_type,
                    "load_ip_info": False
                }
                return res_data

            self.flush_data(site)
            ts = tsqlite()
            ts.dbfile(db_path)

            load_ip_info = self.get_online_ip_library() is not None
            conditions.update({
                "start_date": start_date,
                "end_date": end_date,
            })
            select_sql = self.get_site_logs_sql(conditions)
            # print("Conditions:"+str(conditions))
            # print("Select sql:"+select_sql)
            # ts.table("site_logs").field(fields)
            total_row = 0
            if not no_total:
                total_fields = "count(*)"
                total_sql = select_sql.format(total_fields)
                total_res = ts.query(total_sql)
                total_row = int(total_res[0][0])

            # select_start = datetime.datetime.now()

            if fields == "all":
                fields = "time, ip, method, domain, status_code, protocol, uri, user_agent, body_length, referer, request_time, is_spider, request_headers, ip_list, client_port"
            select_data_sql = select_sql.format(fields)
            # print("select sql:")
            # print(select_data_sql)
            if orderby:
                select_data_sql += " order by " + orderby
            if desc:
                select_data_sql += " desc"

            select_data_sql += " limit " + str(page_size)
            page_start = (page - 1) * page_size
            select_data_sql += " offset " + str(page_start+offset)

            select_data_sql += ";"
            # print("select sql:")
            # print(select_data_sql)
            data = ts.query(select_data_sql)

            # select_end = datetime.datetime.now()
            # diff = select_end-select_start
            # diff_gmtime = time.gmtime(diff.total_seconds())
            # strtime = time.strftime("%H:%M:%S", diff_gmtime)
            # str_msec = '.' + str(diff)[-6:]
            # msec = '%.3f' % float(str_msec)
            # msec = msec[1:]
            # print("查询耗时:{}s".format(strtime+str(msec)))
            _columns = [column.strip() for column in fields.split(",")]
            error_count = 0
            fake_spider_count = 0
            spider_count = 0
            for row in data:
                i = 0
                tmp1 = {}
                for column in _columns:
                    val = row[i]
                    if column == "status_code":
                        if val >= 400:
                            error_count += 1
                    if column == "is_spider":
                        if val == 77:
                            fake_spider_count += 1
                        elif val > 0:
                            spider_count += 1

                    tmp1[column] = val
                    i += 1
                list_data.append(tmp1)
                del (tmp1)

            total_data = {
                "error": error_count,
                "fake_spider": fake_spider_count,
                "spider": spider_count
            }
            domains = []
            res_data = {
                "status": True,
                "query_date": res_query_date,
                "page": page,
                "page_size": page_size,
                "total_row": total_row,
                "list_data": list_data,
                "domains": domains,
                "filter_type": filter_type,
                "load_ip_info": load_ip_info,
                "total_data": total_data
            }
            self.switch_site(get)
            return res_data
        except Exception as e:
            return tool.returnMsg(
                False, 
                "REQUEST_INTERFACE_ERROR",
                args=(
                    tool.getMsg("INTERFACE_LOGS"),
                    str(e),
                )
            )

    def get_site_logs(self, get):
        try:
            site = get.site
            query_date = "today"
            if 'query_date' in get:
                query_date = get.query_date
            query_array = tool.split_query_date(query_date)

            if len(query_array) == 1:
                if "today" in query_array:
                    get.db_path = self.get_log_db_path(site)
                else:
                    get.db_path = self.get_log_db_path(site, history=True) 
                return self.get_site_logs_old(get)

            # print("合并查询")
            # print(query_array)
            cur_page = 1
            if "page" in get:
                cur_page = int(get.page)

            page_size = 20
            if "page_size" in get:
                page_size = int(get.page_size)

            if "no_total_rows" in get:
                no_total = True if get.no_total_rows.lower() == "true" else False

            hot_data = []
            hot_res = {}
            # 热数据
            get.query_date = "today"
            get.check_total = True
            query_array.remove("today")
            get.db_path = self.get_log_db_path(site)
            hot_rows = self.get_site_logs_total(get)["total_row"]
            # print("期望/热数据总行数:")
            # print(cur_page * page_size, hot_rows)
            if cur_page * page_size <= hot_rows:
                return self.get_site_logs_old(get)
            else:
                hot_res = self.get_site_logs_old(get)
                if hot_res["status"]:
                    hot_data = hot_res["list_data"]
                else:
                    return hot_res

            # print("hot data:")
            # print(hot_data)
            # 历史数据
            get.check_total = False
            get.query_date = query_array[0]
            rows = cur_page * page_size
            offset = hot_rows % page_size 
            diff = rows - hot_rows
            his_page = diff//page_size
            his_page_size = page_size
            if diff%page_size>0:
                his_page += 1
            if his_page == 1:  # 中转页
                his_page_size = page_size - offset
                offset = 0
                get.page = 1
            if his_page > 1:
                offset = page_size - offset
                get.page = his_page - 1 
            get.offset = offset
            get.page_size = his_page_size
            get.query_date = query_array[0]
            get.db_path = self.get_log_db_path(site, history=True) 
            res = self.get_site_logs_old(get)
            if res["status"]:
                second_data = res["list_data"]
                hot_res["list_data"] = hot_data + second_data
            else:
                if hot_data:
                    return hot_res
            self.switch_site(get)

            return hot_res
        except Exception as e:
            print("异常: {}".format(e))
            return tool.returnMsg(
                False, 
                "REQUEST_INTERFACE_ERROR",
                args=(
                    tool.getMsg("INTERFACE_LOGS"),
                    str(e),
                )
            )

    def get_all_site(self, get):
        """所有站点信息概览"""

        try:
            ts = None
            query_date = "today"
            if 'query_date' in get:
                query_date = get.query_date

            orderby = "pv"
            if "orderby" in get:
                orderby = get.orderby

            desc = True
            if "desc" in get:
                desc = True if get.desc == "true" else False

            sum_data = {}
            res_data = []
            list_data = []

            start_date, end_date = tool.get_query_date(query_date)
            sites = public.M('sites').field('name').order("addtime").select();

            total_pv = 0
            total_uv = 0
            total_ip = 0
            total_req = 0
            total_length = 0
            total_spider = 0
            total_error = 0
            total_50x = 0
            total_40x = 0
            total_realtime_req = 0
            total_realtime_traffic = 0
            exception_sites = []
            for site_info in sites:
                try:
                    ori_site = site_info["name"]
                    site = self.__get_siteName(ori_site)
                    site_overview_info = self.get_site_overview_sum_data(
                        site, start_date, end_date)
                    data = {
                        "name": ori_site, "pv": 0, "uv": 0, "ip": 0, "req": 0,
                        "length": 0, "spider": 0, "fake_spider": 0, "s50x": 0, "s40x":0
                    }
                    data.update(site_overview_info)
                    realtime_req_list = self.get_realtime_request(site)
                    if len(realtime_req_list) > 0:
                        data["realtime_req"] = realtime_req_list[0]["req"]
                    else:
                        data["realtime_req"] = 0

                    realtime_traffic_list = self.get_realtime_traffic(site)
                    if len(realtime_traffic_list) > 0:
                        data["realtime_traffic"] = realtime_traffic_list[0]["flow"]
                    else:
                        data["realtime_traffic"] = 0

                    total_pv += data["pv"]
                    total_uv += data["uv"]
                    total_ip += data["ip"]
                    total_req += data["req"]
                    total_length += data["length"]
                    total_spider += data["spider"]
                    total_50x += data["s50x"]
                    total_40x += data["s40x"]

                    total_realtime_req += data["realtime_req"]
                    total_realtime_traffic += data["realtime_traffic"]

                    data["status"] = self.get_monitor_status(site)
                    list_data.append(data)
                except Exception as e:
                    msg = str(e)
                    if msg.find("object does not support item assignment") != -1:
                        msg = "数据文件/www/server/total/logs/{}/logs.db已损坏。".format(site)
                    exception_sites.append({"site": ori_site, "err": msg})

            def sort_key(d):
                return d[orderby]

            list_data.sort(key=sort_key, reverse=desc)

            res_data = {
                "sum_data": {
                    "pv": total_pv,
                    "uv": total_uv,
                    "ip": total_ip,
                    "req": total_req,
                    "length": total_length,
                    "spider": total_spider,
                    "s50x": total_50x,
                    "s40x": total_40x,
                    "realtime_req": total_realtime_req,
                    "realtime_traffic": total_realtime_traffic
                },
                "list_data": list_data,
                "orderby": orderby,
                "exception_sites": exception_sites,
                "desc": desc
            }
            return res_data
        except Exception as e:
            return tool.returnMsg(
                False, 
                "REQUEST_INTERFACE_ERROR",
                args = (
                    tool.getMsg("INTERFACE_SITE_LIST"),
                    str(e),
                )
            )

    def __read_frontend_config(self):
        config_json = self.__frontend_path + "/config.json"
        data = {}
        if os.path.exists(config_json):
            data = json.loads(public.readFile(config_json))
        return data

    def set_default_site(self, site):
        config = self.__read_frontend_config()
        config["default_site"] = site
        config_json = self.__frontend_path + "/config.json"
        public.writeFile(config_json, json.dumps(config))
        return True

    def switch_site(self, post):
        site = post.site
        if self.set_default_site(site):
            return public.returnMsg(True, "已切换默认站点为{}".format(site))
        return public.returnMsg(False, "切换默认站点失败。")

    def get_default_site(self):
        config = self.__read_frontend_config()
        default = None
        if "default_site" in config:
            default = config["default_site"]
        if not default:
            site = public.M('sites').field('name').order("addtime").find();
            default = site["name"]
        return default

    def get_site_lists(self, get):
        # self._check_site()
        self.write_site_domains()
        if os.path.exists('/www/server/apache'):
            if not os.path.exists('/usr/local/memcached/bin/memcached'):
                return tool.returnMsg(False, 'MEMCACHE_CHECK')
            if not os.path.exists('/var/run/memcached.pid'):
                return public.returnMsg(False, 'MEMCACHE_CHECK2')
        # modc = self.__get_mod(get)
        # if not cache.get('bt_total'):  return modc

        sites = public.M('sites').field('name').order("addtime").select();
        if len(sites) == 0:
            res_data = {
                "status": False,
                "msg": tool.getMsg("PLEASE_CREATE_SITE")
            }
        else:
            res_site = []
            for site in sites:
                res_site.append(site["name"])

            # if os.path.exists("/www/server/total/logs/btunknownbt"):
            #     res_site.append("btunknownbt")
            default_site = self.get_default_site()
            res_data = {
                "status": True,
                "data": res_site,
                "default": default_site
            }
        return res_data

    def get_total_bysite(self, get):
        # self.__read_config()
        # tmp = self.__config['sites'][get.siteName]
        tmp = {}
        tmp['total'] = self.__get_site_total(get.siteName)
        tmp['site_name'] = get.siteName
        get.s_type = 'request'
        tmp['days'] = self.get_site_total_days(get)
        return tmp


    def get_site_total_days(self, get):
        site = self.__get_siteName(get.siteName)
        # s_type = get.s_type
        # types = {
        #     "request": "req",
        # }
        ts = self.init_ts(site)
        start, end = tool.get_last_days(30)
        days_sql = "select time/100 as time1 from request_stat " \
        "where time between {} and {} group by time1 order by time1 desc".format(start, end)
        results = ts.query(days_sql)
        data = []
        if type(results) == str:
            return data
        for res in results:
            date = str(res[0])
            try:
                date = self.__timekey2date(date)
                data.append(date)
            except:
                pass
        return data

    def get_site_total_days_old(self, get):
        get.siteName = self.__get_siteName(get.siteName)

        path = self.__plugin_path + '/total/' + get.siteName + '/' + get.s_type;
        data = []
        if not os.path.exists(path): return data
        for fname in os.listdir(path):
            if fname == 'total.json': continue;
            data.append(fname.split('.')[0])

        return sorted(data, reverse=True)

    def get_site_network_all(self, get):
        get.siteName = self.__get_siteName(get.siteName)

        query_date = "l7"
        if "query_date" in get:
            query_date = get.query_date

        all_start, all_end = tool.get_query_date(query_date)
        get_total_sql = "select time/100 as time1, sum(length) as length, " \
        "sum(req) as req, sum(uv) as uv, sum(pv) as pv, sum(ip) as ip, " \
        "sum(spider) as spider, sum(status_500) as s500, sum(status_502) as s502, " \
        "sum(status_503) as s503, sum(http_put) as put, sum(http_get) as get, sum(http_post) as post " \
        "from request_stat " \
        "where time >= {} and time <= {} " \
        "group by time1 " \
        "order by time1 desc;".format(all_start, all_end)
        ts = self.init_ts(get.siteName)
        results = ts.query(get_total_sql)
        data = {}
        # network_days = []
        request_days = []
        data['total_size'] = 0
        data['total_request'] = 0
        data['days'] = []
        if type(results) == list: 
            for total_day in results:
                day_req = {}
                
                day_req["date"] = self.__timekey2date(total_day[0])
                day_size = self.get_num_value(total_day[1])
                day_req["size"] = day_size

                data['total_size'] += day_size

                day_req['request'] = self.get_num_value(total_day[2])
                day_req['uv'] = self.get_num_value(total_day[3])
                day_req['pv'] = self.get_num_value(total_day[4])
                day_req['ip'] = self.get_num_value(total_day[5])

                day_req['500'] = self.get_num_value(total_day[7])
                day_req['502'] = self.get_num_value(total_day[8])
                day_req['503'] = self.get_num_value(total_day[9])

                day_req['put'] = self.get_num_value(total_day[10])
                day_req['get'] = self.get_num_value(total_day[11])
                day_req['post'] = self.get_num_value(total_day[12])

                data['total_request'] += day_req["request"]
                data["days"].append(day_req)

        return data

    def get_site_total_byday(self, get):
        get.siteName = self.__get_siteName(get.siteName)
        time_key = self.__today2timekey(get.s_day)
        start_date, end_date = tool.get_query_date(time_key)
        types = {
            "request": "req",
            "network": "length",
        }
        fields = types[get.s_type]
        fields += ",http_get, http_post"
        select_sql = "select time, {} from request_stat where time >= {} and time <= {}"\
            .format(fields, start_date, end_date)
        # print("select sql byday:" + select_sql)
        ts = self.init_ts(get.siteName)
        results = ts.query(select_sql)
        data = []
        if type(results) == list:
            for result in results:
                time_key = str(result[0])
                hour = time_key[len(time_key)-2:]
                value = result[1]
                data.append({"key":hour, "value": value, "GET": result[2], "POST": result[3]})
        
        # filename = self.__plugin_path + '/total/' + get.siteName + '/' + get.s_type + '/' + get.s_day + '.json'
        # if not os.path.exists(filename): return []
        # return self.__sort_json(self.__get_file_json(filename), False)
        return data

    def get_site_total_byspider(self, get):
        get.siteName = self.__get_siteName(get.siteName)
        ts = self.init_ts(get.siteName) 
        columns = ts.query("PRAGMA table_info([{}])".format("spider_stat"))
        fields = []
        for column in columns:
            column_name = column[1]
            if column_name == "time": continue
            fields.append(column_name)
            
        config = self.get_config(get.siteName)
        save_day = config["save_day"]
        all_start, all_end = tool.get_query_date("l"+repr(save_day))
        select_all_sql = "select sum(spider) from request_stat where time between {} and {}".format(all_start, all_end)
        all_results = ts.query(select_all_sql)
        data = {}
        data['total_all'] = 0
        if type(all_results) == list:
            data["total_all"] = self.get_num_value(all_results[0][0])

        query_date = time.strftime('%Y%m%d', time.localtime())
        start_date, end_date = tool.get_query_date(query_date)
        get_spider_sql = "select time/100 as time1, " + ",".join(fields) + \
        " from spider_stat where time between {} and {} group by time1".format(start_date, end_date)
        results = ts.query(get_spider_sql)
        data['total_day'] = 0
        data['days'] = []
        ts.close()

        fields_map = {
            "baidu": "BaiduSpider",
            "google": "Googlebot",
            "sogou": "Sogou web spider",
            "qh360": "360Spider"
        }
        if type(results) == list:
            for total_spider in results:
                tmp = {}
                time_key = total_spider[0]
                tmp['date'] = self.__timekey2date(time_key)
                for i, field in enumerate(fields):
                    if field in fields_map.keys():
                        tmp[fields_map[field]] = total_spider[i+1]
                    else:
                        tmp[field] = total_spider[i+1]
                data['days'].append(tmp)
            data['days'] = sorted(data['days'], key=lambda x: x['date'], reverse=True);
        return data

    def get_site_total_byclient(self, get):
        get.siteName = self.__get_siteName(get.siteName)
        path = self.__plugin_path + '/total/' + get.siteName + '/client';
        data = []
        if not os.path.exists(path): return data
        for fname in os.listdir(path):
            if fname == 'total.json': continue
            filename = path + '/' + fname
            day_data = self.__get_file_json(filename)
            tmp = {}
            tmp['date'] = fname.split('.')[0]
            for s_data in day_data.values():
                for s_key in s_data.keys():
                    if not s_key in tmp:
                        tmp[s_key] = s_data[s_key]
                    else:
                        tmp[s_key] += s_data[s_key]
            data.append(tmp)
        data = sorted(data, key=lambda x: x['date'], reverse=True);
        return data

    def get_site_total_byarea(self, get):
        get.siteName = self.__get_siteName(get.siteName)
        if not 's_day' in get: get.s_day = 'total';
        path = self.__plugin_path + '/total/' + get.siteName + '/area/' + get.s_day + '.json';
        data = {}
        data['date'] = get.s_day
        data['num'] = 0
        data['total'] = []
        if not os.path.exists(path): return data
        day_data = self.__get_file_json(path)
        data['num'] = self.__sum_dict(day_data)
        for s_key in day_data.keys():
            tmp1 = {}
            tmp1['area'] = s_key
            tmp1['num'] = day_data[s_key]
            tmp1['percentage'] = round(
                (float(tmp1['num']) / float(data['num'])) * 100.0, 2)
            data['total'].append(tmp1)
        data['total'] = sorted(data['total'], key=lambda x: x['num'],
                               reverse=True)
        return data

    def __sum_dict(self, data):
        num = 0
        for v in data.values():
            if type(v) == int:
                num += v
            else:
                for d in v.values(): num += d
        return num

    def __sort_json(self, data, dest=True):
        result = []
        for k in data.keys():
            if type(data[k]) == int:
                tmp = {}
                tmp['value'] = data[k]
            else:
                tmp = data[k]
            tmp['key'] = k
            result.append(tmp)
        return sorted(result, key=lambda x: x['key'], reverse=dest)

    def get_site_log_days(self, get):
        srcSiteName = get.siteName
        get.siteName = self.__get_siteName(get.siteName)
        self.__read_config()
        data = {}
        data['log_open'] = self.__config['sites'][srcSiteName]['log_open']
        data['save_day'] = self.__config['sites'][srcSiteName]['save_day']
        path = self.__plugin_path + '/logs/' + get.siteName
        data['days'] = []
        if not os.path.exists(path): return data
        for fname in os.listdir(path):
            if fname == 'error': continue;
            data['days'].append(fname.split('.')[0])
        data['days'] = sorted(data['days'], key=lambda x: x, reverse=True)
        return data

    def remove_site_log_byday(self, get):
        get.siteName = self.__get_siteName(get.siteName)
        s_path = self.__plugin_path + '/logs/' + get.siteName
        if not 'error_log' in get:
            path = s_path + '/' + get.s_day + '.log'
        else:
            path = s_path + '/error/' + get.s_status + '.log'

        if os.path.exists(path): os.remove(path)
        return public.returnMsg(True, '日志清除成功!');

    def remove_site_log(self, get):
        get.siteName = self.__get_siteName(get.siteName)
        s_path = self.__plugin_path + '/logs/' + get.siteName
        public.ExecShell("rm -rf " + s_path)
        return public.returnMsg(True, '日志清除成功!');

    def get_site_log_byday(self, get):
        get.siteName = self.__get_siteName(get.siteName)
        s_path = self.__plugin_path + '/logs/' + get.siteName
        result = {}
        result['total_size'] = 0
        result['size'] = 0
        result['data'] = []
        get.site = get.siteName
        path = s_path + '/logs.db'
        if os.path.exists(path): result['total_size'] = os.path.getsize(path)
        page_size = 10
        get.page_size = page_size
        page = 1
        if 'p' in get:
            page = int(get.p)
            get.page=page
        # if not os.path.exists(s_path): return result
        if not 'error_log' in get:
            if not 's_day' in get: return public.returnMsg(False, '请指定日期!')
            query_date = self.__today2timekey(get.s_day)
            get.query_date = query_date

            results = self.get_site_logs(get)
            # for uname in os.listdir(s_path):
            #     filename = s_path + '/' + uname
            #     if os.path.isdir(filename): continue
            #     result['total_size'] += os.path.getsize(filename)
        else:
            if not 's_status' in get: return public.returnMsg(False, '请指定状态!')
            # s_path += '/error'
            # if not os.path.exists(s_path): return result
            path = s_path + '/' + get.s_status + '.log'
            get.status_code = get.s_status
            results = self.get_site_logs(get)
            # if os.path.exists(path): result['size'] = os.path.getsize(path)
            # for uname in os.listdir(s_path):
            #     filename = s_path + '/' + uname
            #     if os.path.isdir(filename): continue
            #     result['total_size'] += os.path.getsize(filename)

        data = []
        #           0     1   2                4           5         6    7           8            9        10            
        # fields = "time, ip, method, domain, status_code, protocol, uri, user_agent, body_length, referer, request_time, is_spider, request_headers"
        if results["status"]:
            for line in results["list_data"]:
                # print("error log line:")
                # return public.returnMsg(False, str(line))
                # line = json.loads(line)
                data.append([
                    time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(float(line["time"]))),
                    line["ip"],
                    get.siteName,
                    line["method"],
                    line["status_code"],
                    line["uri"],
                    line["body_length"],
                    line["referer"],
                    line["user_agent"],
                    line["protocol"]
                ])
        result['data'] = data
        return result

    def __timekey2date(self, timekey):
        date = str(timekey)
        date = date[0:4]+"-"+date[4:6]+"-"+date[6:]
        return date

    def __today2timekey(self, date):
        time_key = date.replace("-", "")
        return time_key

    def __get_site_total(self, siteName, get=None):
        data = {}
        is_red = False
        if not get: get = get_input()
        if hasattr(get, 'today'):
            today = get['today']
        else:
            today_time = time.localtime()
            today = time.strftime('%Y-%m-%d', today_time)
            is_red = True

        data['client'] = 0
        siteName = self.__get_siteName(siteName)
        # spdata = self.__get_file_json(
        #     self.__plugin_path + '/total/' + siteName + '/client/total.json')
        # for c in spdata.values(): data['client'] += c


        # 获取总流量
        config = self.get_config(siteName)
        save_day = config["save_day"]
        all_start, all_end = tool.get_query_date("l"+repr(save_day))
        get_total_sql = "select sum(length) as length, sum(req) as req, " \
        "sum(spider) as spider from request_stat where time between {} and {}".format(all_start, all_end)

        ts = self.init_ts(siteName)
        results = ts.query(get_total_sql)
        if type(results) == str:
            data["newwork"] = 0
            data["request"] = 0
            data["spider"] = 0
        else:
            data["network"] = self.get_num_value(results[0][0])
            data["request"] = self.get_num_value(results[0][1])
            data["spider"] = self.get_num_value(results[0][2])

        # 获取实时的请求和流量
        data['req_sec'] = 0
        data['flow_sec'] = 0
        realtime_req_list = self.get_realtime_request(siteName)
        if len(realtime_req_list) > 0:
            data["req_sec"] = self.get_num_value(realtime_req_list[0]["req"])
        else:
            data["req_sec"] = 0

        realtime_traffic_list = self.get_realtime_traffic(siteName)
        if len(realtime_traffic_list) > 0:
            data["flow_rec"] = self.get_num_value(realtime_traffic_list[0]["flow"])
        else:
            data["flow_rec"] = 0
                       
        #  获取今日总流量
        data['day_network'] = 0
        time_key = self.__today2timekey(today)
        start, end = tool.get_query_date(time_key)
        get_network_sql = "select sum(length) as length, sum(spider) as spider from request_stat where time between {} and {}".format(start, end)
        day_results = ts.query(get_network_sql)
        # print("site name:"+siteName)
        # print("今日总流量查询结果:"+str(day_results))
        if type(day_results) == list:
            day_network = self.get_num_value(day_results[0][0])
            data['day_network'] = day_network
            day_spider = self.get_num_value(day_results[0][1])
            data["day_spider"] = day_spider


        # path = self.__plugin_path + '/total/' + siteName + '/network/' + today + '.json'
        # if os.path.exists(path):
        #     spdata = self.__get_file_json(path)
        #     for c in spdata.values(): data['day_network'] += c
        # data['request'] = self.__total_request(
        #     self.__plugin_path + '/total/' + siteName + '/request/total.json')
        data['day_request'], data['day_ip'], data['day_pv'], data['day_uv'], \
        data['day_post'], data['day_get'], data['day_put'], data['day_500'], \
        data['day_502'], data['day_503'] = self.__total_request(siteName, time_key)

        # data['spider'] = 0

        # spdata = self.__get_file_json(
        #     self.__plugin_path + '/total/' + siteName + '/spider/total.json')
        # for c in spdata.values(): data['spider'] += c

        # data['day_spider'] = 0
        # path = self.__plugin_path + '/total/' + siteName + '/spider/' + today + '.json'
        data['day_spider_arr'] = {}

        table_info = ts.query("PRAGMA table_info([{}])".format("spider_stat"))
        columns = []
        for column in table_info:
            column_name = column[1]
            if column_name == "time": continue
            columns.append(column_name)

        get_spider_sql = "select time, "+",".join(columns) + " from spider_stat where time between {} and {}".format(start, end)
        spider_results = ts.query(get_spider_sql)

        # fields_map = {
        #     "baidu": "BaiduSpider",
        #     "google": "Googlebot",
        #     "sogou": "Sogou web spider",
        #     "qh360": "360Spider"
        # }

        if type(spider_results) == list:
            for spider_line in spider_results:
                time_key = str(spider_line[0])
                hour = time_key[len(time_key)-2:]
                spider_data = {}
                for i, column in enumerate(columns):
                    # if column in fields_map.keys():
                    #     column = fields_map[column]
                    spider_data[column] = spider_line[i+1] 
                data['day_spider_arr'][hour] = spider_data

        # if os.path.exists(path):
        #     spdata = self.__get_file_json(path)
        #     data['day_spider_arr'] = spdata
        #     for c in spdata.values():
        #         for d in c.values(): data['day_spider'] += d

        ts.close()

        if is_red:
            try:
                data['7day_total'] = []
                for i in range(6):
                    get.today = (datetime.date.today() + datetime.timedelta(
                        ~(i + 1) + 1)).strftime("%Y-%m-%d")
                    tmp = self.__get_site_total(siteName, get)
                    tmp['date'] = get.today
                    data['7day_total'].insert(0, tmp)
            except:
                pass
        return data

    def __get_site_total_old(self, siteName, get=None):
        data = {}
        is_red = False
        if not get: get = get_input()
        if hasattr(get, 'today'):
            today = get['today']
        else:
            today_time = time.localtime()
            today = time.strftime('%Y-%m-%d', today_time)
            is_red = True

        data['client'] = 0
        siteName = self.__get_siteName(siteName)
        spdata = self.__get_file_json(
            self.__plugin_path + '/total/' + siteName + '/client/total.json')
        for c in spdata.values(): data['client'] += c

        data['network'] = self.__get_file_json(
            self.__plugin_path + '/total/' + siteName + '/network/total.json',
            0)
        req_sec_file = self.__plugin_path + '/total/' + siteName + '/req_sec.json'
        data['req_sec'] = 0
        data['flow_sec'] = 0
        if os.path.exists(req_sec_file):
            if time.time() - os.stat(req_sec_file).st_mtime < 10:
                data['req_sec'] = self.__get_file_json(req_sec_file, 0)
                data['flow_sec'] = self.__get_file_json(
                    self.__plugin_path + '/total/' + siteName + '/flow_sec.json',
                    0)
        data['day_network'] = 0
        path = self.__plugin_path + '/total/' + siteName + '/network/' + today + '.json'
        if os.path.exists(path):
            spdata = self.__get_file_json(path)
            for c in spdata.values(): data['day_network'] += c
        data['request'] = self.__total_request(
            self.__plugin_path + '/total/' + siteName + '/request/total.json')
        data['day_request'], data['day_ip'], data['day_pv'], data['day_uv'], \
        data['day_post'], data['day_get'], data['day_put'], data['day_500'], \
        data['day_502'], data['day_503'] = self.__total_request(
            self.__plugin_path + '/total/' + siteName + '/request/' + today + '.json')
        data['spider'] = 0

        spdata = self.__get_file_json(
            self.__plugin_path + '/total/' + siteName + '/spider/total.json')
        for c in spdata.values(): data['spider'] += c

        data['day_spider'] = 0
        path = self.__plugin_path + '/total/' + siteName + '/spider/' + today + '.json'
        data['day_spider_arr'] = {}
        if os.path.exists(path):
            spdata = self.__get_file_json(path)
            data['day_spider_arr'] = spdata
            for c in spdata.values():
                for d in c.values(): data['day_spider'] += d
        if is_red:
            try:
                data['7day_total'] = []
                for i in range(6):
                    get.today = (datetime.date.today() + datetime.timedelta(
                        ~(i + 1) + 1)).strftime("%Y-%m-%d")
                    tmp = self.__get_site_total(siteName, get)
                    tmp['date'] = get.today
                    data['7day_total'].insert(0, tmp)
            except:
                pass
        return data

    def __get_site_total_bysite(self, siteName):
        data = {}
        siteName = self.__get_siteName(siteName)
        data['client'] = self.__get_file_json(
            self.__plugin_path + '/total/' + siteName + '/client/total.json')
        data['area'] = self.__get_file_json(
            self.__plugin_path + '/total/' + siteName + '/area/total.json')
        data['network'] = self.__get_file_json(
            self.__plugin_path + '/total/' + siteName + '/network/total.json',
            0)
        data['request'] = self.__get_file_json(
            self.__plugin_path + '/total/' + siteName + '/request/total.json')
        data['spider'] = self.__get_file_json(
            self.__plugin_path + '/total/' + siteName + '/spider/total.json')
        return data

    def __get_siteName(self, siteName):
        db_file = self.__plugin_path + '/total/logs/' + siteName + '/logs.db'
        if os.path.isfile(db_file): return siteName

        cache_key = "SITE_NAME"+"_"+siteName
        if cache.get(cache_key):
            return cache.get(cache_key)

        pid = public.M('sites').where('name=?', (siteName,)).getField('id');
        if not pid: 
            cache.set(cache_key, siteName)
            return siteName

        domains = public.M('domain').where('pid=?', (pid,)).field(
            'name').select()
        for domain in domains:
            db_file = self.__plugin_path + '/total/logs/' + domain["name"] + '/logs.db'
            if os.path.isfile(db_file): 
                siteName = domain['name']
                break
        cache.set(cache_key, siteName.replace('_', '.'))
        return cache.get(cache_key)

    def write_lua_config(self, config=None):
        if not config:
            config = json.loads(public.readFile("/www/server/total/config.json"))
        lua_config = LuaMaker.makeLuaTable(config)
        lua_config = "return " + lua_config
        public.WriteFile("/www/server/total/total_config.lua", lua_config)

    def write_site_domains(self):
        sites = public.M('sites').field('name,id').select();
        my_domains = []
        for my_site in sites:
            tmp = {}
            tmp['name'] = my_site['name']
            tmp_domains = public.M('domain').where('pid=?',
                                                   (my_site['id'],)).field(
                'name').select()
            tmp['domains'] = []
            for domain in tmp_domains:
                tmp['domains'].append(domain['name'])
            binding_domains = public.M('binding').where('pid=?',
                                                        (my_site['id'],)).field(
                'domain').select()
            for domain in binding_domains:
                tmp['domains'].append(domain['domain'])
            my_domains.append(tmp)
        public.writeFile(self.__plugin_path + '/domains.json',
                         json.dumps(my_domains))
        config_domains = LuaMaker.makeLuaTable(my_domains)
        domains_str = "return " + config_domains
        public.WriteFile("/www/server/total/domains.lua", domains_str)
        return my_domains

    def get_site_domains(self, get):
        """查找站点的绑定域名列表"""
        siteName = get.site
        domains = []
        pid = public.M('sites').where('name=?', (siteName,)).getField('id');
        if not pid: 
            return domains

        objs = public.M('domain').where('pid=?', (pid,)).field(
            'name').select()
        for domain in objs:
            domains.append(domain["name"])
        return domains

    def get_num_value(self, value):
        if value is None:
            return 0
        return value

    def __total_request(self, site, query_date, get_total=False):
        start_time_key, end_time_key = tool.get_query_date(query_date)

        select_request_sql  = "select " \
        "sum(req) as req, sum(uv) as uv, sum(pv) as pv, sum(ip) as ip, " \
        "sum(spider) as spider, sum(status_500) as s500, sum(status_502) as s502, " \
        "sum(status_503) as s503, sum(http_put) as put, sum(http_get) as get, sum(http_post) as post " \
        "from request_stat " \
        "where time between {} and {}".format(start_time_key, end_time_key)

        ts = self.init_ts(site)
        results = ts.query(select_request_sql)
        # print("total request result:"+str(results))
        day_request = 0
        day_ip = 0
        day_pv = 0
        day_uv = 0
        day_post = 0
        day_get = 0
        day_put = 0
        day_500 = 0
        day_503 = 0
        day_502 = 0
        if type(results) == list:
            day_request = self.get_num_value(results[0][0])
            if get_total:
                ts.close()
                return day_request
            day_uv = self.get_num_value(results[0][1])
            day_pv = self.get_num_value(results[0][2])
            day_ip = self.get_num_value(results[0][3])

            day_500 = self.get_num_value(results[0][5])
            day_502 = self.get_num_value(results[0][6])
            day_503 = self.get_num_value(results[0][7])

            day_put = self.get_num_value(results[0][8])
            day_get = self.get_num_value(results[0][9])
            day_post = self.get_num_value(results[0][10])
        
        ts.close()
        return day_request, day_ip, day_pv, day_uv, day_post, day_get, day_put, day_500, day_502, day_503
        
    def __total_request_old(self, path):
        day_request = 0
        day_ip = 0
        day_pv = 0
        day_uv = 0
        day_post = 0
        day_get = 0
        day_put = 0
        day_500 = 0
        day_503 = 0
        day_502 = 0
        if os.path.exists(path):
            spdata = self.__get_file_json(path)
            if path.find('total.json') != -1:
                for c in spdata:
                    if re.match("^\d+$", c): day_request += spdata[c]
                return day_request

            for c in spdata.values():
                for d in c:
                    if re.match("^\d+$", d): day_request += c[d]
                    if 'ip' == d: day_ip += c['ip']
                    if 'pv' == d: day_pv += c['pv']
                    if 'uv' == d: day_uv += c['uv']
                    if 'POST' == d: day_post += c['POST']
                    if 'GET' == d: day_get += c['GET']
                    if 'PUT' == d: day_put += c['PUT']
                    if '500' == d: day_500 += c['500']
                    if '503' == d: day_503 += c['503']
                    if '502' == d: day_502 += c['502']

        if path.find('total.json') != -1: return day_request
        return day_request, day_ip, day_pv, day_uv, day_post, day_get, day_put, day_500, day_502, day_503

    def __remove_log_file(self, siteName):
        siteName = self.__get_siteName(siteName)
        path = self.__plugin_path + '/total/' + siteName
        if os.path.exists(path): public.ExecShell("rm -rf " + path)
        path = self.__plugin_path + '/logs/' + siteName
        if os.path.exists(path): public.ExecShell("rm -rf " + path)

    def __get_file_json(self, filename, defaultv={}):
        try:
            if not os.path.exists(filename): return defaultv;
            return json.loads(public.readFile(filename))
        except:
            os.remove(filename)
            return defaultv

    def __write_config(self):
        public.writeFile(self.__plugin_path + '/config.json',
                         json.dumps(self.__config))
        public.serviceReload();

    def __read_config(self, site="global"):
        if self.__config: return True
        data = public.readFile(self.__plugin_path + '/config.json')
        self.__config = json.loads(data)

    def get_test(self, get):
        return self.__read_config();

    def __write_logs(self, logstr):
        public.WriteLog(tool.getMsg("PLUGIN_NAME"), logstr)

    def return_file(self, file):
        for root, dirs, files in os.walk(file):
            return files

    def get_ip_total(self, get):
        server_name = get.server_name.strip()
        day = get.day.strip()
        path = '/www/server/total/total/' + server_name + '/ip_total/' + day
        if not os.path.exists(path): return public.returnMsg(False, '无日志')
        file_data = self.return_file(path)
        result = []
        for i in file_data:
            try:
                tmp = {}
                tmp['ip'] = i.split('.json')[0]
                tmp['totla'] = json.loads(public.ReadFile(path + '/' + i))[
                    'totla']
                result.append(tmp)
            except:
                continue
        return result

    def migrate_total(self, get):
        import threading
        migrate_thread = threading.Thread(target=total_migrate().migrate_total)
        migrate_thread.setDaemon(True)
        migrate_thread.start()
        return public.returnMsg(True, "正在迁移中，请稍后。")

    def get_migrate_status(self, get):
        tm = total_migrate()
        res = tm.get_migrate_status()
        status = True if res["status"] == "completed" else False
        if not status:
            check_path = "/www/server/total/total"
            if not os.path.isdir(check_path) or public.get_path_size(
                    check_path) == 0:
                tm.set_migrate_status("completed")
                return tm.get_migrate_status()
        return res

    def get_site_settings(self, site):
        """获取站点配置"""

        config_path = "/www/server/total/config.json"
        config = self.__get_file_json(config_path)
        # frontend_config = self.__read_frontend_config()

        res_config = {}
        if site not in config.keys():
            res_config = config["global"]
            res_config["push_report"] = False
        else:
            res_config = config[site]

        for k, v in config["global"].items():
            if k not in res_config.keys():
                if k == "push_report":
                    res_config[k] = False
                else:
                    res_config[k] = v
        res_config["default_site"] = self.get_default_site()
        return res_config

    def get_settings_info(self, get):
        """获取配置信息
        适用插件前端调用"""
        site = None
        if "site" in get:
            site = self.__get_siteName(get.site)
        if not site:
            return public.returnMsg(False, "请选择站点。")

        settings_info = self.get_site_settings(site)
        for k, v in settings_info.items():
            if k == "exclude_url": 
                # print("Exclude url:"+json.dumps(settings_info["exclude_url"]))
                settings_info["exclude_url"] = json.dumps(settings_info["exclude_url"])
                continue
            if type(v) == list:
                _v = [str(x) for x in v]
                settings_info[k] = ",".join(_v)
        if site == "global":
                try:
                    spiders_update = public.readFile("/www/server/total/xspiders/latest_update.log")
                    if spiders_update:
                        spiders_update = float(spiders_update)
                        settings_info["spiders_latest_update"] = spiders_update
                    spiders_integrity = True
                    spider_tags = [1, 2, 3, 4, 5, 6, 7] 
                    for x in spider_tags:
                        spider_path = "/www/server/total/xspiders/{}.json".format(x)
                        if not os.path.exists(spider_path):
                            spiders_integrity = False
                            break
                        spiders = json.loads(public.readFile(spider_path))
                        if len(spiders) == 0:
                            spiders_integrity = False
                            break
                    settings_info["spiders_integrity"] = spiders_integrity
                except:
                    pass
        return settings_info

    def set_settings(self, get):
        """修改配置文件"""
        site = None
        if "site" in get:
            site = self.__get_siteName(get.site.strip())
        if not site:
            return public.returnMsg(False, tool.getMsg("PLEASE_SELECT_SITE"))
        targets = []
        if site != "global":
            if site.find(",") < 0:
                targets.append(site)
            else:
                targets = [x for x in site.split(",") if x.strip()]

        new_config = {}
        monitor = None
        if "monitor" in get:
            monitor = True if get.monitor == "true" else False
            new_config["monitor"] = monitor
        default_site = None
        if "default_site" in get:
            default_site = get.default_site
            self.set_default_site(default_site)
        auto_refresh = None
        if "autorefresh" in get:
            auto_refresh = True if get.autorefresh == "true" else False
            new_config["autorefresh"] = auto_refresh
        refresh_interval = 3
        if "refresh_interval" in get:
            refresh_interval = int(get.refresh_interval)
            if refresh_interval < 3:
                refresh_interval = 3
            new_config["refresh_interval"] = refresh_interval
        cdn = True
        if "cdn" in get:
            cdn = True if get.cdn == "true" else False
            new_config["cdn"] = cdn
        cdn_headers = None
        if "cdn_headers" in get:
            cdn_headers = get.cdn_headers
            if cdn_headers == "null":
                cdn_headers = []
            else:
                cdn_headers = [x.strip() for x in cdn_headers.split(",")]
            new_config["cdn_headers"] = cdn_headers

        exclude_extension = None
        if "exclude_extension" in get:
            exclude_extension = get.exclude_extension
            if exclude_extension == "null":
                exclude_extension = []
            else:
                exclude_extension = [x.strip() for x in
                                     exclude_extension.split(",")]
            new_config["exclude_extension"] = exclude_extension
        exclude_status = []
        if "exclude_status" in get:
            exclude_status = get.exclude_status
            if exclude_status == "null":
                exclude_status = []
            else:
                exclude_status = [x.strip() for x in exclude_status.split(",")]
            new_config["exclude_status"] = exclude_status
        save_day = 180
        if "save_day" in get:
            save_day = int(get.save_day)
            new_config["save_day"] = save_day

        if "exclude_url" in get:
            try:
                _url_conf = json.loads(get.exclude_url)
                new_config["exclude_url"] = _url_conf
            except Exception as e:
                print(tool.getMsg("EXCLUDE_FORMAT_ERROR"))
                new_config["exclude_url"] = []

        if "exclude_ip" in get:
            exclude_ip = get.exclude_ip
            if exclude_ip != "null":
                new_config["exclude_ip"] = exclude_ip.split(",")
            else:
                new_config["exclude_ip"] = []

        if "statistics_machine_access" in get:
            new_config["statistics_machine_access"] = True if get.statistics_machine_access.lower() == "true" else False
        
        if "statistics_uri" in get:
            new_config["statistics_uri"] = True if get.statistics_uri.lower() == "true" else False

        if "statistics_ip" in get:
            new_config["statistics_ip"] = True if get.statistics_ip.lower() == "true" else False

        if "record_post_args" in get:
            new_config["record_post_args"] = True if get.record_post_args.lower() == "true" else False
        
        if "record_get_403_args" in get:
            new_config["record_get_403_args"] = True if get.record_get_403_args.lower() == "true" else False

        data_dir = "/www/server/total/logs"
        if "data_dir" in get:
            data_dir = get.data_dir.strip()
            new_config["data_dir"] = data_dir

        ip_top_num = None
        if "ip_top_num" in get:
            ip_top_num = int(get.ip_top_num)
            if ip_top_num <= 0 or ip_top_num > 2000:
                ip_top_num = 50
            new_config["ip_top_num"] = ip_top_num

        uri_top_num = None
        if "uri_top_num" in get:
            uri_top_num = int(get.uri_top_num)
            if uri_top_num <= 0 or uri_top_num > 2000:
                uri_top_num = 50
            new_config["uri_top_num"] = uri_top_num
        
        push_report = False
        if "push_report" in get:
            push_report = True if get.push_report.lower() == "true" else False
            new_config["push_report"] = push_report
        
        # 插件本身参数
        reload_service = True
        if "reload_service" in get:
            reload_service = True if get.push_report.lower() == "true" else False

        config_path = "/www/server/total/config.json"
        config_data = self.__get_file_json(config_path)

        if site != "global":
            for target_site in targets:
                site_config = {}
                if target_site in config_data.keys():
                    site_config = config_data[target_site]

                if new_config:
                    if "exclude_ip" in new_config.keys():
                        if "exclude_ip" in site_config.keys():
                            site_config["old_exclude_ip"] = site_config["exclude_ip"]
                        else:
                            if "exclude_ip" in config_data["global"].keys():
                                site_config["old_exclude_ip"] = config_data["global"]["exclude_ip"]

                        reload_exclude_url_file = os.path.join(self.get_data_dir(), target_site, "reload_exclude_ip.pl")
                        public.writeFile(reload_exclude_url_file, "reload")
                    site_config.update(new_config)
                    config_data[target_site] = site_config
            try:
                if new_config["push_report"] == True:
                    # 打开推送开关全局设置
                    global_config = config_data["global"]
                    if "push_report" in global_config.keys():
                        if not global_config["push_report"]:
                            global_config["push_report"] = True
                    else:
                        global_config["push_report"] = True

            except:
                pass
        else:
            if new_config:

                if "exclude_ip" in new_config.keys():
                    # 全局配置修改排除IP，所有未记录配置的站点都标记再次重载排除IP
                    # tosites = public.M('sites').field('name').order("addtime").select();
                    # targets = [self.__get_siteName(x["name"]) for x in tosites]
                    # for xsite in targets:
                    #     reload_exclude_ip = False
                    #     if xsite not in config_data.keys(): 
                    #         reload_exclude_ip = True
                    #         config_data[xsite] = {}
                    #     if xsite in config_data.keys() and "exclude_ip" not in config_data[xsite].keys():
                    #         reload_exclude_ip = True

                    #     if reload_exclude_ip:
                    #         config_data[xsite]["old_exclude_ip"] = config_data["global"]["exclude_ip"]
                    
                    if "exclude_ip" in config_data["global"].keys():
                        config_data["global"]["old_exclude_ip"] = config_data["global"]["exclude_ip"]
                    # 调整：仅标记全局排除规则变化
                    reload_exclude_url_file = os.path.join(self.get_data_dir(), "reload_exclude_ip.pl")
                    public.writeFile(reload_exclude_url_file, "reload")

                config = config_data["global"]
                config.update(new_config)
                config_data["global"] = config
                self.set_monitor_status(config["monitor"])

        # print("New config:" + json.dumps(config_data))
        # json配置文件写入
        public.writeFile(config_path, json.dumps(config_data))


        # lua配置文件写入前置处理
        for xsite, conf in config_data.items():
            if "exclude_url" in conf.keys():
                url_conf = {}
                for i, _o in enumerate(conf["exclude_url"]):
                    if _o["mode"] == "regular":
                        _o["url"] = self.parse_regular_url(_o["url"])
                    url_conf[str(i+1)] = _o
                config_data[xsite]["exclude_url"] = url_conf

            if "exclude_ip" in conf.keys() and len(conf["exclude_ip"]) >0:
                ips = {}
                for ip in conf["exclude_ip"]:
                    if ip.find("-")>0:
                        for xip in self.parse_ips(ip):
                            ips[str(len(ips)+1)] = xip
                    else:
                        ips[str(len(ips)+1)] = ip
                config_data[xsite]["exclude_ip"] = ips

            if "old_exclude_ip" in conf.keys() and len(conf["old_exclude_ip"]) >0:
                if xsite != "global":
                    reload_exclude_url_file = os.path.join(self.get_data_dir(), xsite, "reload_exclude_ip.pl")
                else:
                    reload_exclude_url_file = os.path.join(self.get_data_dir(), "reload_exclude_ip.pl")
                if not os.path.isfile(reload_exclude_url_file):
                    del config_data[xsite]["old_exclude_ip"]
                else:
                    ips = {}
                    for ip in conf["old_exclude_ip"]:
                        if ip.find("-")>0:
                            for xip in self.parse_ips(ip):
                                ips[str(len(ips)+1)] = xip
                        else:
                            ips[str(len(ips)+1)] = ip
                    if ips:
                        config_data[xsite]["old_exclude_ip"] = ips

        self.write_lua_config(config_data)
        
        if reload_service: 
            public.serviceReload()
        return tool.returnMsg(True, "CONFIGURATION_SUCCESSFULLY")

    def parse_ips(self, ips):
        """生成区间IP列表"""
        sip, eip = ips.split("-")
        ip_prefix = sip[:sip.rfind(".")+1]
        snum = int(sip[sip.rfind(".")+1:])
        enum = int(eip[eip.rfind(".")+1:])
        ip_list = []
        for x in range(snum, enum+1):
            if x > 255:
                break
            ip_list.append(ip_prefix + str(x))
        return ip_list
        
    def parse_regular_url(self, url):
        """处理url中的特殊字符，以符合lua配置文件语法"""
        v = url
        if v.find("?") >=0 and v.find("\\\?")<0:
            if v.find("\?")>=0:
                v = v.replace("\?", "\\\?")
            elif v.find("?")>=0:
                v = v.replace("?", "\\\?")
        return v

    def set_monitor_status(self, status):
        if status == True:
            print("开启监控.")
            if os.path.isfile(self.close_file):
                os.remove(self.close_file)
            if os.path.isfile("/www/server/nginx/sbin/nginx"):
                print(os.system("cp /www/server/panel/plugin/total/total_nginx.conf /www/server/panel/vhost/nginx/total.conf"))
            if os.path.isfile("/www/server/apache/bin/httpd"):
                os.system("cp /www/server/panel/plugin/total/total_httpd.conf /www/server/panel/vhost/apache/total.conf")
        else:
            public.WriteFile(self.close_file, "closing")
            os.system("rm -f /www/server/panel/vhost/nginx/total.conf")
            os.system("rm -f /www/server/panel/vhost/apache/total.conf")

    def sync_settings(self, get):
        """同步站点配置"""
        profile = None
        if "profile" in get:
            profile = self.__get_siteName(get.profile.strip())
        tosites = None
        if "tosites" in get:
            tosites = get.tosites.strip()
        targets = []
        if tosites != "all":
            if tosites.find(",") < 0:
                targets.append(self.__get_siteName(tosites))
            else:
                targets = [self.__get_siteName(x) for x in tosites.split(",") if x.strip()]
        else:
            tosites = public.M('sites').field('name').order("addtime").select();
            targets = [self.__get_siteName(x["name"]) for x in tosites]

        new_config = {}
        monitor = None
        if "monitor" in get:
            monitor = True if get.monitor == "true" else False
            new_config["monitor"] = monitor
        auto_refresh = None
        if "autorefresh" in get:
            auto_refresh = True if get.autorefresh == "true" else False
            new_config["autorefresh"] = auto_refresh
        refresh_interval = 3
        if "refresh_interval" in get:
            refresh_interval = int(get.refresh_interval)
            if refresh_interval < 3:
                refresh_interval = 3
            new_config["refresh_interval"] = refresh_interval
        # cdn = True
        # if "cdn" in get:
        #     cdn = True if get.cdn=="true" else False
        #     new_config["cdn"] = cdn
        cdn_headers = None
        if "cdn_headers" in get:
            cdn_headers = get.cdn_headers
            if cdn_headers == "null":
                cdn_headers = []
            else:
                cdn_headers = [x.strip() for x in cdn_headers.split(",")]
            new_config["cdn_headers"] = cdn_headers

        exclude_extension = None
        if "exclude_extension" in get:
            exclude_extension = get.exclude_extension
            if exclude_extension == "null":
                exclude_extension = []
            else:
                exclude_extension = [x.strip() for x in
                                     exclude_extension.split(",")]
            new_config["exclude_extension"] = exclude_extension
        exclude_status = []
        if "exclude_status" in get:
            exclude_status = get.exclude_status
            if exclude_status == "null":
                exclude_status = []
            else:
                exclude_status = [x.strip() for x in exclude_status.split(",")]
            new_config["exclude_status"] = exclude_status

        if "exclude_url" in get:
            try:
                _url_conf = json.loads(get.exclude_url)
                new_config["exclude_url"] = _url_conf
            except Exception as e:
                print(tool.getMsg("EXCLUDE_FORMAT_ERROR"))
                new_config["exclude_url"] = []

        if "exclude_ip" in get:
            exclude_ip = get.exclude_ip
            if exclude_ip != "null":
                new_config["exclude_ip"] = exclude_ip.split(",")
            else:
                new_config["exclude_ip"] = []

        if "statistics_machine_access" in get:
            new_config["statistics_machine_access"] = True if get.statistics_machine_access.lower() == "true" else False

        if "record_post_args" in get:
            new_config["record_post_args"] = True if get.record_post_args.lower() == "true" else False

        if "record_get_403_args" in get:
            new_config["record_get_403_args"] = True if get.record_get_403_args.lower() == "true" else False

        save_day = 180
        if "save_day" in get:
            save_day = int(get.save_day)
            new_config["save_day"] = save_day

        # print("Update new config:")
        # print(new_config)

        # print("Target sites:")
        # print(targets)

        # print("Profile:")
        # print(profile)

        config_path = "/www/server/total/config.json"
        config_data = self.__get_file_json(config_path)
        # 保存站点配置
        current_config = {}
        if profile in config_data.keys():
            current_config = config_data[profile]

        if "exclude_ip" in new_config.keys():
            if profile != "global":
                if "exclude_ip" in current_config.keys():
                    current_config["old_exclude_ip"] = current_config["exclude_ip"]
                else:
                    if "exclude_ip" in config_data["global"].keys():
                        current_config["old_exclude_ip"] = config_data["global"]["exclude_ip"]
                reload_exclude_url_file = os.path.join(self.get_data_dir(), profile, "reload_exclude_ip.pl")
                public.writeFile(reload_exclude_url_file, "reload")

        current_config.update(new_config)
        config_data[profile] = current_config

        # 同步配置
        for target_site in targets:
            site_profile = {}
            if target_site in config_data.keys():
                site_profile = config_data[target_site]

            if new_config:

                if "exclude_ip" in new_config.keys():
                    if target_site != "global":
                        if "exclude_ip" in site_profile.keys():
                            site_profile["old_exclude_ip"] = site_profile["exclude_ip"]
                        else:
                            if "exclude_ip" in config_data["global"].keys():
                                site_profile["old_exclude_ip"] = config_data["global"]["exclude_ip"]
                        reload_exclude_url_file = os.path.join(self.get_data_dir(), target_site, "reload_exclude_ip.pl")
                        public.writeFile(reload_exclude_url_file, "reload")

                if profile == "global" and target_site != "global":
                    # 如果是从全局配置同步，删掉站点的自定义配置，从新恢复跟全局配置同步
                    for key, conf in new_config.items():
                        if key in site_profile.keys():
                            del site_profile[key]
                else:
                    site_profile.update(new_config)
                config_data[target_site] = site_profile

        public.writeFile(config_path, json.dumps(config_data))
        
        for xsite, conf in config_data.items():
            if "exclude_url" in conf.keys():
                url_conf = {}
                for i, _o in enumerate(conf["exclude_url"]):
                    if _o["mode"] == "regular":
                        _o["url"] = self.parse_regular_url(_o["url"])
                    url_conf[str(i+1)] = _o
                config_data[xsite]["exclude_url"] = url_conf

            if "exclude_ip" in conf.keys() and len(conf["exclude_ip"]) >0:
                ips = {}
                for ip in conf["exclude_ip"]:
                    if ip.find("-")>0:
                        for xip in self.parse_ips(ip):
                            ips[str(len(ips)+1)] = xip
                    else:
                        ips[str(len(ips)+1)] = ip
                config_data[xsite]["exclude_ip"] = ips

            if "old_exclude_ip" in conf.keys() and len(conf["old_exclude_ip"]) >0:
                # 清理已经重载过的排除记录
                reload_exclude_url_file = os.path.join(self.get_data_dir(), xsite, "reload_exclude_ip.pl")
                if not os.path.isfile(reload_exclude_url_file):
                    del config_data[xsite]["old_exclude_ip"]
                else:
                    ips = {}
                    for ip in conf["old_exclude_ip"]:
                        if ip.find("-")>0:
                            for xip in self.parse_ips(ip):
                                ips[str(len(ips)+1)] = xip
                        else:
                            ips[str(len(ips)+1)] = ip
                    if ips:
                        config_data[xsite]["old_exclude_ip"] = ips

        lua_config = LuaMaker.makeLuaTable(config_data)
        lua_config = "return " + lua_config
        public.WriteFile("/www/server/total/total_config.lua", lua_config)
        public.serviceReload()
        return tool.returnMsg(True, "CONFIGURATION_SYNC_SUCCESSFULLY")

    def get_uri_stat(self, get, flush=True):
        try:
            ts = None
            site = "all"
            if "site" in get:
                site = self.__get_siteName(get.site)
            query_date = "l30"
            if "query_date" in get:
                query_date = get.query_date
            
            top = 0
            if "top" in get:
                top = int(get.top)

            uri_top_num = 50
            settings = self.get_site_settings("global")
            if "uri_top_num" in settings.keys():
                uri_top_num = int(settings["uri_top_num"])
            if not top:
                top = uri_top_num
            if not top:
                top = 50

            fields, flow_fields = self.get_data_fields(query_date)
            if not fields:
                return {
                    "query_date": query_date,
                    "top": top,
                    "total_req": 0,
                    "total_flow": 0,
                    "data": [],
                    "uri_top_num": uri_top_num
                }

            self.flush_data(site)
            if site == "all":
                sites = public.M('sites').field('name').order("addtime").select();
            else:
                sites = [{"name": site}]

            data = []
            for site_info in sites:
                site_name = site_info["name"]
                try:
                    # print("Get {} uri statistics.".format(site_name))
                    db_path = self.get_log_db_path(site_name)
                    if not os.path.isfile(db_path):
                        continue
            
                    ts = tsqlite()
                    ts.dbfile(db_path)

                    if flush:
                        self.flush_data(site_name)

                    time_start, time_end = tool.get_query_date(query_date)
                    total_sql = "select sum(req), sum(length) from request_stat where time>={} and time <={}".format(time_start, time_end)
                    total_result = ts.query(total_sql)
                    
                    total_req = 0
                    total_flow = 0
                    if len(total_result)>0 and type(total_result[0])!=str:
                        total_req = total_result[0][0] or 0
                        total_flow = total_result[0][1] or 0

                    select_sql = "select uri, ({}) as uri_count, ({}) as uri_flow from uri_stat where uri_count > 0 order by uri_count desc limit {};".format(fields, flow_fields, top)
                    api_result = ts.query(select_sql)
                    for i, line in enumerate(api_result):
                        sub_data = {}
                        _uri = line[0]
                        if not _uri:continue
                        sub_data["no"] = i+1
                        sub_data["site"] = site_name
                        sub_data["uri"] = _uri

                        count = line[1]
                        count_rate = 0
                        if count >0 and total_req > 0:
                            count_rate = round(count/total_req*100, 2)
                        sub_data["count"] = count
                        sub_data["count_rate"] = count_rate

                        flow = line[2]
                        flow_rate = 0
                        if flow > 0 and total_flow > 0:
                            flow_rate = round(flow/total_flow*100, 2)

                        sub_data["flow"] = flow
                        sub_data["flow_rate"] = flow_rate
                        data.append(sub_data)
                    if ts:
                        ts.close()
                except Exception as e:
                    print(tool.getMsg("REQUEST_SITE_INTERFACE_ERROR", (site_name, "get_uri_stat", str(e))))
                    # print("Get {} uri stat error: {}.".format(site_name, str(e)))

            return {
                "query_date": query_date,
                "top": top,
                "data": data,
                "total_req": total_req,
                "total_flow": total_flow,
                "uri_top_num": uri_top_num
            }
        except Exception as e:
            return tool.returnMsg(
                False, 
                "REQUEST_INTERFACE_ERROR", 
                args=(tool.getMsg("INTERFACE_URI_STAT"), str(e),)
            )
        finally:
            if ts:
                ts.close()

    def get_ip_area_id(self, ip):
        """
        " search ip by ip2region
        """
        res = ""
        dbFile = "/www/server/panel/plugin/total/library/ip.db"
        if (not os.path.isfile(dbFile)) or (not os.path.exists(dbFile)):
            # print("[Error]: Specified db file is not exists.")
            return res
    
        try:
            from ip2Region import Ip2Region
            searcher = Ip2Region(dbFile)
            info = searcher.binarySearch(ip)
            city_id = res
            if "city_id" in info.keys():
                city_id = info["city_id"]
            return city_id
        except:pass
        return ""
    
    def search_area(self, area_id):
        try:

            if not area_id:
                return "-"
            area_id = str(area_id)
            
            services = {
                "9999": "内网IP",
                "9998": "阿里云",
                "9997": "腾讯云",
                "9996": "华为云",
                "9995": "电信",
                "9994": "移动",
                "9993": "教育网",
                "9992": "联通"
            }
            if area_id in services.keys():
                return services[area_id]

            if not self.global_region:
                region_file = os.path.join("/www/server/panel/plugin/total", "global_region.csv")
                region_data = public.readFile(region_file)
                for region in region_data.split("\n"):
                    line = region.split(",")
                    if len(line) != 5: continue
                    self.global_region[line[0]] = line
            
            region = self.global_region.get(area_id, [])
            if len(region) == 5:
                city = region[2]
                _p = self.global_region.get(region[1], None)
                province = ""
                if _p:
                    province = _p[2]
                if province and province != city:
                    return province +","+ city
                else:
                    return city
        except Exception as e:
            print("Search area error: %s" % e)
        return "-"

    def get_data_fields(self, query_date):
        fields = ""
        flow_fields = ""
        now = time.localtime()
        last_month = now.tm_mon-1
        if last_month <= 0:
            last_month = 12
        if query_date.startswith("l"):
            year = now.tm_year
            month = now.tm_mon
            day = now.tm_mday

            _, last_month_days = calendar.monthrange(year, last_month)
            days = int(query_date[1:])
            if days == 30 :
                if last_month_days == 31:
                    days = 31

            for i in range(day, 0, -1):
                if fields:
                    fields += "+"
                fields += "day" + repr(i)

                if flow_fields:
                    flow_fields += "+"
                flow_fields += "flow" + repr(i)

                days -= 1
                if days <= 0:
                    break

            days = min(last_month_days, days)
            if days > 0:
                for i in range(last_month_days, 0, -1):
                    if fields:
                        fields += "+"
                    fields += "day" + repr(i)

                    if flow_fields:
                        flow_fields += "+"
                    flow_fields += "flow" + repr(i)
                    days -= 1
                    if days <= 0:
                        break

        elif query_date == "today":
            day = now.tm_mday
            fields = "day" + repr(day)
            flow_fields = "flow" + repr(day)
        elif query_date == "yesterday":
            day = now.tm_mday
            if day > 1:
                yesterday = day - 1
                fields = "day" + repr(yesterday)
                flow_fields = "flow" + repr(yesterday)
            if day == 1:
                _, last_month_days = calendar.monthrange(now.tm_year, last_month)
                fields = "day" + repr(last_month_days)
                flow_fields = "flow" + repr(last_month_days)
        elif query_date.find("-") > 0:
            _start, _end = query_date.split("-")
            start = time.strptime(_start, "%Y%m%d")
            day_start = int(time.strftime("%d", start))
            end = time.strptime(_end, "%Y%m%d")
            day_end = int(time.strftime("%d", end))
            if now.tm_mon == start.tm_mon:
                for i in range(day_end, 0, -1):
                    if fields:
                        fields += "+"
                    fields += "day" + repr(i)

                    if flow_fields:
                        flow_fields += "+"
                    flow_fields += "flow" + repr(i)
                    if i==day_start:
                        break
            else:
                for i in range(day_end, 0, -1):
                    if fields:
                        fields += "+"
                    fields += "day" + repr(i)

                    if flow_fields:
                        flow_fields += "+"
                    flow_fields += "flow" + repr(i)

                _, last_month_days = calendar.monthrange(now.tm_year, last_month)
                for j in range(last_month_days, day_start-1, -1):
                    if fields:
                        fields += "+"
                    fields += "day" + repr(j)

                    if flow_fields:
                        flow_fields += "+"
                    flow_fields += "flow" + repr(j)
            
        return fields, flow_fields

    def get_ip_stat(self, get, flush=True):
        try:
            ts = None
            site = "all"
            if "site" in get:
                site = self.__get_siteName(get.site)
            query_date = "l30"
            if "query_date" in get:
                query_date = get.query_date
            
            top = 0
            if "top" in get:
                top = int(get.top)
            
            ip_top_num = 50
            settings = self.get_site_settings("global")
            if "ip_top_num" in settings.keys():
                ip_top_num = int(settings["ip_top_num"])
            if not top:
                top = ip_top_num
            if not top:
                top = 50
            
            fields, flow_fields = self.get_data_fields(query_date)
            if not fields:
                return {
                    "query_date": query_date,
                    "top": top,
                    "total_req": 0,
                    "total_flow": 0,
                    "data": [],
                    "ip_top_num": ip_top_num
                }

            data = []
            if site == "all":
                sites = public.M('sites').field('name').order("addtime").select()
            else:
                sites = [{"name":site}]

            to_access_online_api = self.get_online_ip_library()
            for site_info in sites:
                site_name = ""
                try:
                    site_name = site_info["name"]
                    # print("Get site:{} ip stat.".format(site_name))

                    if flush:
                        self.flush_data(site_name)
                    
                    db_path = self.get_log_db_path(site_name)
                    if not os.path.isfile(db_path):
                        continue

                    ts = tsqlite()
                    ts.dbfile(db_path)

                    time_start, time_end = tool.get_query_date(query_date)
                    total_sql = "select sum(req), sum(length) from request_stat where time>={} and time <={}".format(time_start, time_end)
                    total_result = ts.query(total_sql)
                    
                    total_req = 0
                    total_flow = 0
                    if len(total_result)>0 and type(total_result[0])!=str:
                        total_req = total_result[0][0] or 0
                        total_flow = total_result[0][1] or 0
                     
                    select_sql = "select ip, area, ({}) as ip_count, ({}) as ip_flow from ip_stat where ip_count> 0 order by ip_count desc limit {};".format(fields, flow_fields, top)
                    # print("select sql:"+select_sql)
                    ips = []
                    ip_result = ts.query(select_sql)
                    # tmp_data = {}
                    ip_map = {}
                    for i, line in enumerate(ip_result):
                        append = False
                        sub_data = {}
                        sub_data["no"] = i+1
                        sub_data["site"] = site_name
                        ip = line[0]
                        if not ip: continue
                        sub_data["ip"] = ip
                        area_id = line[1]
                        area = "-"
                        if to_access_online_api:
                            if ipaddress.ip_address(ip.strip()).is_private:
                                sub_data["area"] = "内网IP"
                                sub_data["carrier"] = "-"
                                # append = True
                            else:
                                online_cache_key = "ONLINE_AREA_" + ip
                                cache_info = cache.get(online_cache_key)
                                if cache_info:
                                    if ip in cache_info.keys():
                                        info = cache_info[ip]
                                        sub_data["area"] = self.get_online_area(info)
                                        sub_data["carrier"] = info.get("carrier", "-")
                                        # append = True
                                    else:
                                        # ips.append(ip)
                                        ip_map[ip] = i
                                else:
                                    # ips.append(ip)
                                    ip_map[ip] = i
                        else:
                            # append = True
                            if not area_id:
                                area_id = self.get_ip_area_id(ip)
                            area_cache_key = "XAREA_" + repr(area_id)
                            if cache.get(area_cache_key):
                                area = cache.get(area_cache_key)
                            else:
                                area = self.search_area(area_id)
                                cache.set(area_cache_key, area)
                            sub_data["area"] = area

                        count = line[2]
                        count_rate = 0
                        if count >0 and total_req > 0:
                            count_rate = round(count/total_req*100, 2)
                        sub_data["count"] = count
                        sub_data["count_rate"] = count_rate

                        flow = line[3]
                        flow_rate = 0
                        sub_data["flow"] = flow

                        if flow > 0 and total_flow > 0:
                            flow_rate = round(flow/total_flow*100, 2)
                        sub_data["flow_rate"] = flow_rate
                        # tmp_data[ip] = sub_data

                        data.append(sub_data)

                    ips = list(ip_map.keys())
                    if ips:
                        ip_data = self.get_ip_data_from_server(ips)
                        if ip_data:
                            for _ip, info in ip_data.items():
                                area = self.get_online_area(info)
                                ip_inx = ip_map[_ip]
                                data[ip_inx]["area"] = area
                                carrier = info.get("carrier", "")
                                data[ip_inx]["carrier"] = carrier

                                online_cache_key = "ONLINE_AREA_" + _ip
                                cache_data = {
                                    _ip: info
                                }
                                cache.set(online_cache_key, cache_data, 604800)

                            # for _ip, _info in tmp_data.items():
                            #     data.append(_info)
                        else:
                            # 未查到信息
                            for _ip, inx in ip_map.items():
                                area = "-"
                                area_id = self.get_ip_area_id(ip)
                                area_cache_key = "XAREA_" + repr(area_id)
                                if cache.get(area_cache_key):
                                    area = cache.get(area_cache_key)
                                else:
                                    area = self.search_area(area_id)
                                    cache.set(area_cache_key, area)
                                data[inx]["area"] = area
                                data[inx]["carrier"] = ''
                    if ts:
                        ts.close()
                except Exception as e:
                    print("Get {} ip stat error: {}.".format(site_name, str(e)))

            return {
                "query_date": query_date,
                "top": top,
                "total_req": total_req,
                "total_flow": total_flow,
                "data": data,
                "ip_top_num": ip_top_num,
                "online_data": to_access_online_api is not None
                # "fields": fields
            }
        except Exception as e:
            return tool.returnMsg(
                False, 
                "REQUEST_INTERFACE_ERROR", 
                args=(tool.getMsg("INTERFACE_IP_STAT"), str(e),)
            )
        finally:
            if ts:
                ts.close()

    def generate_area_stat(self, site, query_date):
        try:
            db_path = self.get_log_db_path(site)
            start_date, end_date = tool.get_query_date(query_date=query_date) 
            # print("start date: {}".format(start_date))

            today = time.strftime("%Y%m%d", time.localtime())
            start_gen_date = time.strptime(str(start_date//100), "%Y%m%d")
            end_gen = str(end_date//100)
            ts = tsqlite()
            ts.dbfile(db_path)
            ts.execute("BEGIN TRANSACTION;")
            while True:
                # print("正在生成 {} 的地区统计数据...".format())
                print(tool.getMsg("GENERATING_REGIONAL_STAT", args=(time.strftime("%Y-%m-%d", start_gen_date),)))
                if not self.get_online_ip_library():
                    day = time.strftime("%d", start_gen_date)
                    select_sql = "select ip from ip_stat where day{}>0 and area=\"\"".format(int(day))
                    area_result = ts.query(select_sql)
                    # print(area_result)
                    # print("length of result:"+str(len(area_result)))
                    area_data = {}
                    i = 0
                    for i, line in enumerate(area_result):
                        ip = line[0]
                        area_id = self.get_ip_area_id(ip)
                        ts.execute("UPDATE ip_stat set area=? where ip=?", (area_id,ip,), auto_commit=False)
                else:
                    # print("从在线库生成地区数据。")
                    day = time.strftime("%d", start_gen_date)
                    select_sql = "select ip from ip_stat where day{}>0 and area=\"\"".format(int(day))
                    ip_result = ts.query(select_sql)                    
                    ips = ""
                    for i, line in enumerate(ip_result):
                        if ips:
                            ips += ","
                        ips += line[0]
                    res = self.get_ip_data_from_server(ips)
                    if res:
                        for ip, info in res.items():
                            area = ""
                            area = info.get("province", "")
                            if not area:
                                area = info.get("country", "")
                            if len(area) > 8:
                                area = area[0:8]
                            ts.execute("UPDATE ip_stat set area=? where ip=?", (area,ip,), auto_commit=False)
                # print("{} 条IP地区信息已生成。".format(i))
                time_key = time.strftime("%Y%m%d", start_gen_date)
                # print("today: {} /start data:{} /end date:{}".format(today, time_key, end_gen))
                if time_key == end_gen or time_key == today:
                    break
                start_gen_date = time.localtime(time.mktime((start_gen_date.tm_year, start_gen_date.tm_mon, start_gen_date.tm_mday+1, 0, 0, 0, 0, 0, 0)))
            ts.commit()
        except Exception as e:
            print(tool.getMsg("GENERATE_AREA_INFO", args=(str(e),)))
        
    def get_area_stat(self, get, flush=True, format_count=False):
        """获取地区访问统计
        
        :flush 是否及时刷新数据库
        :format_count 是否格式化数值输出，格式化之后数值将变成字符格式
        """
        try:
            # print("flush: {}, format: {}".format(flush, format_count))
            ts = None
            site = "all"
            if "site" in get:
                site = self.__get_siteName(get.site)
            query_date = "l30"
            if "query_date" in get:
                query_date = get.query_date
            
            top = 10
            if "top" in get:
                top = int(get.top)
            
            fields, flow_fields = self.get_data_fields(query_date)
            if not fields:
                return {
                    "query_date": query_date,
                    "top": top,
                    "total_req": 0,
                    "total_flow": 0,
                    "data": [],
                }

            data = []
            if site == "all":
                sites = public.M('sites').field('name').order("addtime").select()
            else:
                sites = [{"name":site}]

            for site_info in sites:
                site_name = ""
                try:
                    site_name = site_info["name"]
                    # print("Get site:{} ip stat.".format(site_name))

                    if flush:
                        self.flush_data(site_name)
                    
                    db_path = self.get_log_db_path(site_name)
                    if not os.path.isfile(db_path):
                        continue

                    ts = tsqlite()
                    ts.dbfile(db_path)

                    time_start, time_end = tool.get_query_date(query_date)
                    total_sql = "select sum(req), sum(length) from request_stat where time>={} and time <={}".format(time_start, time_end)
                    total_result = ts.query(total_sql)
                    
                    total_req = 0
                    total_flow = 0
                    if len(total_result)>0 and type(total_result[0])!=str:
                        # print("total result:"+str(total_result))
                        total_req = total_result[0][0] or 0
                        total_flow = total_result[0][1] or 0
                     
                    # print("total req:" + repr(total_req))
                    # print("total flow:" + repr(total_flow))
                    select_sql = "select area, sum({}) as area_count, sum({}) as area_flow from ip_stat where area!=0 group by area having area_count>0 order by area_count desc limit {};".format(fields, flow_fields, top)
                    # print("Area select sql:"+select_sql)
                    area_result = ts.query(select_sql)
                    for i, line in enumerate(area_result):
                        sub_data = {}
                        sub_data["no"] = i+1
                        sub_data["site"] = site_name
                        area_id = line[0]
                        area_cache_key = "XAREA_"+ repr(area_id)
                        if not cache.get(area_cache_key):
                            _area = self.search_area(area_id)
                            cache.set(area_cache_key, _area)
                        sub_data["area"] = cache.get(area_cache_key)
                        count = line[1]
                        count_rate = 0
                        if count >0 and total_req > 0:
                            count_rate = round(count/total_req*100, 2)
                    
                        sub_data["count_rate"] = count_rate
                        if count > 0 and format_count:
                            sub_data["count"] = "{:,}".format(count)

                        flow = line[2]
                        flow_rate = 0
                        sub_data["flow"] = flow

                        if flow > 0 and total_flow > 0:
                            flow_rate = round(flow/total_flow*100, 2)
                        sub_data["flow_rate"] = flow_rate
                        if flow > 0 and format_count:
                            sub_data["flow"] = public.to_size(flow)
                            # print("Formated flow data:"+sub_data["flow"])
                        data.append(sub_data)
                    if ts:
                        ts.close()
                except Exception as e:
                    print("Get {} area stat error: {}.".format(site_name, str(e)))
            return {
                "query_date": query_date,
                "top": top,
                "total_req": total_req,
                "total_flow": total_flow,
                "data": data,
                # "fields": fields
            }
        except Exception as e:
            return tool.returnMsg(
                False, 
                "REQUEST_INTERFACE_ERROR", 
                args=(tool.getMsg("INTERFACE_AREA_STAT"), str(e),)
            )
        finally:
            if ts:
                ts.close()

    def get_referer_stat(self, get, flush=True, format_count=False):
        """获取来源访问统计
        
        :flush 是否及时刷新数据库
        :format_count 是否格式化数值输出，格式化之后数值将变成字符格式
        """
        try:
            ts = None
            site = "all"
            if "site" in get:
                site = self.__get_siteName(get.site)
            query_date = "l30"
            if "query_date" in get:
                query_date = get.query_date
            
            top = 10
            if "top" in get:
                top = int(get.top)

            data = []
            if site == "all":
                sites = public.M('sites').field('name').order("addtime").select()
            else:
                sites = [{"name":site}]

            for site_info in sites:
                site_name = ""
                try:
                    site_name = site_info["name"]
                    # print("Get site:{} ip stat.".format(site_name))

                    if flush:
                        self.flush_data(site_name)
                    
                    db_path = self.get_log_db_path(site_name)
                    if not os.path.isfile(db_path):
                        continue

                    ts = tsqlite()
                    ts.dbfile(db_path)

                    time_start, time_end = tool.get_query_date(query_date)
                    total_sql = "select sum(req) from request_stat where time>={} and time <={}".format(time_start, time_end)
                    total_result = ts.query(total_sql)
                    
                    total_req = 0
                    if len(total_result)>0 and type(total_result[0])!=str:
                        total_req = total_result[0][0] or 0
                     
                    # print("total req:" + repr(total_req))
                    # print("total flow:" + repr(total_flow))
                    select_sql = "select domain, sum(count) as t_count from referer_stat where time>={} and time<={} group by domain order by t_count desc limit {};".format(time_start//100, time_end//100, top)
                    referer_result = ts.query(select_sql)
                    # print("referer result:")
                    # print(referer_result)
                    for i, line in enumerate(referer_result):
                        sub_data = {}
                        sub_data["no"] = i+1
                        sub_data["domain"] = line[0]

                        count = line[1]
                        if not count:
                            sub_data["count"] = 0
                            count = 0
                        count_rate = 0
                        if count >0 and total_req > 0:
                            count_rate = round(count/total_req*100, 2)
                        sub_data["count_rate"] = count_rate

                        if count > 0 and format_count:
                            sub_data["count"] = "{:,}".format(count)
                        else:
                            sub_data["count"] = count
                        data.append(sub_data)
                    if ts:
                        ts.close()
                except Exception as e:
                    print("Get {} referer stat error: {}.".format(site_name, str(e)))
            return {
                "query_date": query_date,
                "top": top,
                "total_req": total_req,
                "data": data,
                # "fields": fields
            }
        except Exception as e:
            return tool.returnMsg(
                False, 
                "REQUEST_INTERFACE_ERROR",
                args=(
                    tool.getMsg("INTERFACE_REFERER_STAT"),
                    str(e)
                )
            )
        finally:
            if ts:
                ts.close()

    def get_path_space_info(self, get):
        """获取目录占用空间大小"""
        path = None
        if "path" in get:
            path = get.path
        
        if not path:
            return 0

        if not os.path.isdir(path):
            return public.returnMsg(False, "不是有效目录。")

        disk_info = psutil.disk_usage(path)
        disk_free = disk_info.free
        disk_total = disk_info.total
        # disk_free_percent = disk_free / disk_total

        path_size = public.get_path_size(path)
        return {
            "path": path,
            "disk_total": disk_total,
            "disk_free": disk_free,
            "path_size": path_size
        }

    def quick_change_data_dir(self, get):
        get.quick_mode = "true"
        return self.change_data_dir(get)

    def change_data_dir(self, get):
        """更换数据存储目录"""
        data_dir = None
        if "data_dir" in get:
            data_dir = get.data_dir.strip()
            if not os.path.isdir(data_dir):
                data_dir = None
        target_data_dir = None
        if "target_data_dir" in get:
            target_data_dir = get.target_data_dir.strip()
            if not os.path.isdir(target_data_dir):
                os.makedirs(target_data_dir)
        quick_mode = False
        if "quick_mode" in get:
            quick_mode = True if get.quick_mode == "true" else False

        if data_dir is None:
            return public.returnMsg(False, "现存储路径不是有效目录!")
        if target_data_dir is None:
            if quick_mode:
                target_data_dir = data_dir
            else:
                return public.returnMsg(False, "目标路径不是有效目录!")
        if not quick_mode:
            if target_data_dir == data_dir:
                return public.returnMsg(False, "目标路径相同，无需更换!")

        monitor_status = False
        get.site = "global"
        try:
            settings = self.get_site_settings("global")
            if settings and "monitor" in settings:
                monitor_status = settings["monitor"]
            if monitor_status:
                get.monitor = "false"
                self.set_settings(get)

            from total_logs import change_data_dir
            change_res = change_data_dir(data_dir, target_data_dir, quick_mode=quick_mode)
            if change_res:
                if target_data_dir[-1] == "/":
                    target_data_dir = target_data_dir[0:-1]
                get.data_dir = target_data_dir
                if monitor_status:
                    get.monitor = monitor_status
                self.set_settings(get)
                if quick_mode:
                    msg = "清除网站数据成功。"
                    public.WriteLog("网站监控", msg)
                    return public.returnMsg(True, msg)
                else:
                    msg = "目录由 {} 更换为 {} 成功。".format(data_dir, target_data_dir)
                    public.WriteLog("网站监控", msg)
                    return public.returnMsg(True, msg)
            else:
                if quick_mode:
                    msg = "清除网站数据失败!"
                    public.WriteLog("网站监控", msg)
                    return public.returnMsg(False, msg)
                else:
                    msg = "目录由 {} 更换为 {} 出现错误！".format(data_dir, target_data_dir)
                    public.WriteLog("网站监控", msg)
                    return public.returnMsg(False, msg)
        except Exception as e:
            if quick_mode:
                msg = "清除网站数据失败: {}".format(str(e))
                public.WriteLog("网站监控", msg)
                return public.returnMsg(False, msg)
            else:
                msg = "目录由 {} 更换为 {} 出现错误: {}".format(data_dir, target_data_dir, str(e))
                public.WriteLog("网站监控", msg)
                return public.returnMsg(False, msg)
        finally:
            if monitor_status:
                get.monitor = "true"
                self.set_settings(get)

    def get_report_list(self, get):
        """获取报表列表 """
        try:
            report_conn = None
            report_cur = None
            site = get.site
            year = time.strftime("%Y", time.localtime())
            if "year" in get:
                year = get.year

            import sqlite3
            report_db = os.path.join(self.__frontend_path, "report.db")
            report_conn = sqlite3.connect(report_db)
            report_cur = report_conn.cursor()
            reportor = report_cur.execute("select report_id, sequence, report_cycle, report_type, generate_time, file_name, file_size from report where site='{}' and year='{}'".format(site, year))
            report = reportor.fetchone()
            # print(report)
            data = []
            while report: 
                file_name = os.path.join(self.__frontend_path, "reports", site, report[5])
                file_size = report[6] 
                data.append({
                    "report_id" : report[0],
                    "sequence" : report[1],
                    "report_cycle" : report[2],
                    "report_type" : report[3],
                    "generate_time" : report[4],
                    "file_size": file_size
                })
                report = reportor.fetchone()

            settings = self.get_site_settings(site)
            push_report = False
            if "push_report" in settings.keys():
                push_report = settings["push_report"]
            return {
                "status": True,
                "data": data,
                "push_report": push_report
            }
        except Exception as e:
            return tool.returnMsg(
                False,
                "REQUEST_INTERFACE_ERROR",
                args=(
                    tool.getMsg("INTERFACE_REPORT"),
                    str(e),
                )
            )
        finally:
            if report_cur:
                report_cur.close()
            if report_conn:
                report_conn.close()

    def download_report(self, get):
        """下载PDF格式报告"""
        try:
            report_conn = None
            report_cur = None
            report_id = get.report_id

            import sqlite3
            report_db = os.path.join(self.__frontend_path, "report.db")
            report_conn = sqlite3.connect(report_db)
            report_cur = report_conn.cursor()
            reportor = report_cur.execute("select file_name from report where report_id={}".format(report_id))
            report = reportor.fetchone()
            if not report:
                return tool.returnMsg(False, "REPORT_NOT_EXISTS")
            report_file_name = report[0]

            pdf_path = os.path.join(self.__frontend_path, "pdfs")
            file_name = os.path.join(pdf_path, report_file_name + ".pdf")
            if not os.path.isfile(file_name):
                if not file_name.endswith(".html"):
                    file_name = os.path.join(self.__frontend_path, "reports", report_file_name+".html")
                else:
                    file_name = os.path.join(self.__frontend_path, "reports", report_file_name)
            return {
                "status": True,
                "data": file_name
            }
        except Exception as e:
            print("下载报表失败:" +str(e))
            return tool.returnMsg(
                False, 
                "REPORT_DOWNLOAD_FAILED",
            )
        finally:
            if report_cur:
                report_cur.close()
            if report_conn:
                report_conn.close()

    def preview_report(self, get):
        """预览报告"""
        try:
            report_conn = None
            report_cur = None
            report_id = get.report_id
            site= self.__get_siteName(get.site)
            # preview_type = "html"
            import sqlite3
            report_db = os.path.join(self.__frontend_path, "report.db")
            report_conn = sqlite3.connect(report_db)
            report_cur = report_conn.cursor()
            reportor = report_cur.execute("select file_name from report where report_id={}".format(report_id))
            report = reportor.fetchone()
            if not report:
                return tool.returnMsg(False, "REPORT_NOT_EXISTS")
            report_file_name = report[0]

            file_name = os.path.join(self.__frontend_path, "reports", site, report_file_name+".html")
            public.writeFile(os.path.join(self.__frontend_path, "templates", "preview_report.html"), public.readFile(file_name))

            if not os.path.isfile(file_name):
                return tool.returnMsg(False, "REPORT_NOT_EXISTS")
            return {
                "status": True,
                "data": file_name
            }
        except Exception as e:
            public.writeFile(
                os.path.join(self.__frontend_path, "templates", "preview_report.html"), 
                tool.getMsg("REPORT_PREVIEW_ERROR", args=(str(e),))
            )
            return tool.returnMsg(
                False,
                "REPORT_PREVIEW_ERROR",
                args=(
                    str(e),
                )
            )
        finally:
            if report_cur:
                report_cur.close()
            if report_conn:
                report_conn.close()

    def erase_ip_stat(self, get):
        """擦除ip统计数据"""
        monitor_status = True 
        config_path = "/www/server/total/config.json"
        try:
            conn = None
            cur = None

            settings = {}
            global_settings = {}
            if os.path.isfile(config_path):
                settings = json.loads(public.readFile(config_path))
                if "global" in settings:
                    global_settings = settings["global"]
                    monitor_status = global_settings["monitor"]

            # print("原监控状态:"+str(monitor_status))
            if monitor_status and global_settings:
                global_settings["monitor"] = False
                public.writeFile(config_path, json.dumps(settings))
                self.write_lua_config(settings)
                self.set_monitor_status(False)
                # print("监控报表已关闭。")

            site= self.__get_siteName(get.site)
            import sqlite3
            conn = sqlite3.connect(self.get_log_db_path(site))
            cur = conn.cursor()
            table_name = "ip_stat"
            selector = cur.execute("PRAGMA table_info([{}]);".format(table_name))
            update_fields = ""
            for c in selector.fetchall():
                column_name = c[1]
                if column_name == "ip": continue
                if update_fields:
                    update_fields += ","
                if column_name == "area": 
                    update_fields += column_name + "=\"\""
                    continue
                update_fields += column_name + "=0"
            update_sql = "UPDATE {} SET {};".format(table_name, update_fields)
            cur.execute(update_sql) 
            conn.commit()

            return tool.returnMsg(True, "ERASE_IP_STAT_SUCCESSFULLY") 
        except Exception as e:
            return tool.returnMsg(
                False,
                "REQUEST_INTERFACE_ERROR",
                args = (
                    tool.getMsg("INTERFACE_ERASE_IP_STAT"),
                    str(e),
                )
            ) 
        finally:
            if cur:
                cur.close()
            if conn:
                conn.close()

            if monitor_status and settings:
                settings = json.loads(public.readFile(config_path))
                global_settings = settings["global"]
                global_settings["monitor"] = True
                public.writeFile(config_path, json.dumps(settings))
                self.write_lua_config(settings)
                self.set_monitor_status(True)
                # print("监控报表已开启。")

    def erase_uri_stat(self, get):
        """擦除URI统计数据"""
        monitor_status = True 
        config_path = "/www/server/total/config.json"
        try:
            conn = None
            cur = None

            settings = {}
            global_settings = {}
            if os.path.isfile(config_path):
                settings = json.loads(public.readFile(config_path))
                if "global" in settings:
                    global_settings = settings["global"]
                    monitor_status = global_settings["monitor"]

            # print("原监控状态:"+str(monitor_status))
            if monitor_status and global_settings:
                global_settings["monitor"] = False
                public.writeFile(config_path, json.dumps(settings))
                self.write_lua_config(settings)
                self.set_monitor_status(False)
                # print("监控报表已关闭。")

            site= self.__get_siteName(get.site)
            import sqlite3
            conn = sqlite3.connect(self.get_log_db_path(site))
            cur = conn.cursor()
            table_name = "uri_stat"
            selector = cur.execute("PRAGMA table_info([{}]);".format(table_name))
            update_fields = ""
            for c in selector.fetchall():
                column_name = c[1]
                if column_name == "uri": continue
                if column_name == "uri_md5": continue
                if update_fields:
                    update_fields += ","
                update_fields += column_name + "=0"
            update_sql = "UPDATE {} SET {};".format(table_name, update_fields)
            cur.execute(update_sql) 
            conn.commit()

            return tool.returnMsg(True, "ERASE_IP_STAT_SUCCESSFULLY") 
        except Exception as e:
            return tool.returnMsg(
                False,
                "REQUEST_INTERFACE_ERROR",
                args = (
                    tool.getMsg("INTERFACE_ERASE_URI_STAT"),
                    str(e),
                )
            ) 
        finally:
            if cur:
                cur.close()
            if conn:
                conn.close()

            if monitor_status and settings:
                settings = json.loads(public.readFile(config_path))
                global_settings = settings["global"]
                global_settings["monitor"] = True
                public.writeFile(config_path, json.dumps(settings))
                self.write_lua_config(settings)
                self.set_monitor_status(True)
                # print("监控报表已开启。")
    
    def export_site_logs(self, get):

        """根据网站日志搜索结果导出日志数据"""
        try:
            site = get.site
            allow_fields = ["time","ip","client_port","method","domain","status_code","protocol","uri","user_agent","body_length","referer","request_time","is_spider","request_headers", "ip_list"]
            headers = ["时间","真实IP","客户端端口", "类型","域名","状态","协议","URL","User Agent","响应大小(字节)","来路","耗时(毫秒)","蜘蛛类型","请求头", "完整IP列表"]
            lang = public.GetLanguage()
            if lang.find("Chinese") < 0:
                headers = allow_fields
            fields = "all"
            headers_str = ""
            from flask import request
            ua = request.headers.get("User-Agent")
            encode = "utf-8"
            if ua.find("Windows") >= 0:
                encode = "gbk"
            export_error = False
            if "export_error" in get:
                export_error = True if get.export_error == "true" else False

            if "fields" in get:
                fields = get.fields
                indexes = [allow_fields.index(f) for f in fields.split(",") if f and f.strip() in allow_fields]
                fields = ""
                for inx in indexes:
                    _f = allow_fields[inx]
                    if fields:
                        fields += ","
                    fields += _f

                    _h = headers[inx]
                    if headers_str:
                        headers_str += ","
                    headers_str += _h

            if fields.find(",")<0:
                fields = "distinct "+fields
            # print("fields:")
            # print(fields)

            get.fields = fields
            total_row = -1
            if "total_row" in get:
                total_row = int(get.total_row)
            if total_row < 0:
                if not export_error:
                    total_row = self.get_site_logs_total(get)["total_row"]
                else:
                    total_row = self.get_site_error_logs_total(get)["total_row"]
            if total_row < 1:
                return tool.returnMsg(False, "EXPORT_DATA_IS_NULL")
            
            output_dir = os.path.join(self.__frontend_path, "output")
            if not os.path.isdir(output_dir):
                os.mkdir(output_dir)

            now = time.strftime("%Y%m%d%H%M", time.localtime())
            output_file = os.path.join(output_dir, "{}_{}_logs.csv".format(site, now))
            if export_error:
                output_file = os.path.join(output_dir, "{}_{}_errlogs.csv".format(site, now))

            if os.path.isfile(output_file):
                os.remove(output_file)
            page_size = 1000
            total_page =  round(total_row // page_size)
            if total_page < 1:
                total_page = 1
            else:
                if total_row % page_size > 0:
                    total_page += 1
            page = 1
            # print("total_row:{}/total_page:{}".format(total_row, total_page))
            if is_py3:
                fp = open(output_file, "a", encoding=encode)
            else:
                fp = open(output_file, "a")
            fp.write(headers_str+"\n")
            if is_py3:
                fp.close()
                fp = open(output_file, "a", encoding="utf-8")

            spider_table = {
                "baidu":1,
                "bing":2,
                "qh360" : 3,
                "google" : 4,
                "bytes" : 5,
                "sogou" : 6,
                "youdao" : 7,
                "soso" : 8,
                "dnspod" : 9,
                "yandex" : 10,
                "yisou" : 11,
                "other" : 12
            }
            while page<=total_page:
                get.page = page
                get.page_size = page_size
                get.no_total_rows = "true"
                if not export_error:
                    logs = self.get_site_logs(get)
                else:
                    logs = self.get_site_error_logs(get)
                list_data = logs["list_data"]
                for log in list_data:
                    log_line = ""
                    # print("log keys:"+str(log.keys()))
                    df = [_key.replace("distinct ", "") for _key in log.keys()]
                    # print("df:"+str(df))
                    for data_field in allow_fields:
                        k = data_field
                        v = ""
                        if k in df:
                            if k in log.keys():
                                v = log[k]
                            else:
                                v = log["distinct "+k]
                        else:
                            continue

                        if not v and v!=0:
                            v = ""
                        if k == "is_spider":
                            for sname, inx in spider_table.items():
                                if inx == v:
                                    v = sname
                                    break
                        if k == "time":
                            _time = time.localtime(v)
                            v = time.strftime("%Y/%m/%d %H:%M:%S", _time)
                        if k == "user_agent":
                            if v:
                                v = "\"" + v + "\""
                        if k == "request_headers":
                            if v:
                                try:
                                    obj = json.loads(v)
                                    tv = ""
                                    for sk, sv in obj.items():
                                        if tv:
                                            tv+= ";"
                                        tv += sk + "=" + str(sv)
                                    v = tv
                                except:
                                    pass
                        if k == "client_port":
                            if not v or v==-1:
                                v = ""
                        if log_line:
                            log_line += ","
                        log_line += str(v)
                    fp.write(log_line+"\n")
                page += 1
            fp.close()
            # if os.path.isfile(output_file):
            #     print("文件存在")
            return {
                "status": True,
                "file_name": output_file
            }
        except Exception as e:
            return tool.returnMsg(
                False,
                "REQUEST_INTERFACE_ERROR",
                args = (
                    tool.getMsg("INTERFACE_EXPORT_LOGS"),
                    str(e),
                )
            )

    def get_online_ip_library(self):
        request_addr = None
        try:
            from pluginAuth import Plugin
            tm = Plugin("btiplibrary")
            res = tm.get_fun("get_request_address")()
            if res and "status" in res and res["status"]:
                request_addr = res["msg"]
        except Exception as e:
            pass
            # print("获取ip库地址出错。")
            # print(e)
        return request_addr

    def get_ip_info(self, get):
        ip = get.ip
        simplify = False
        if "simplify" in get:
            simplify = True if get.simplify == "true" else False

        request_addr = self.get_online_ip_library()
        res = self.get_ip_data_from_server(ip, request_addr=request_addr)
        if simplify:
            for ip, info in res.items():
                res[ip] = {
                    "area": self.get_online_area(info),
                    "carrier": info.get("carrier", "-")
                }
        return {
            "status": True,
            "data": res
        }
    
    def get_ip_data_from_server(self, ips, request_addr=None):
        try:
            # ip_record_json = self.__plugin_path()
            if not request_addr:
                request_addr = "https://www.bt.cn/api/panel/get_ip_info"
            if not ips:
                return None
            ips_text = ips
            if type(ips) == list:
                ips_text = ",".join(ips)
            elif type(ips) != str: 
                ips_text = str(ips)
            data = {
                "ip": ips_text
            }
            if ips_text.find(",") == -1:
                online_cache_key = "ONLINE_AREA_" + ips_text
                cache_data = cache.get(online_cache_key)
                if cache_data:
                    return cache_data

            raw_res = public.httpPost(request_addr, data)
            if raw_res:
                try:
                    res = json.loads(raw_res)
                    if res and ips_text.find(",") == -1:
                        online_cache_key = "ONLINE_AREA_" + ips_text
                        cache.set(online_cache_key, res, 604800)
                    return res
                except: pass
        except Exception as e:
            print("查询在线IPAPI出错: {}".format(e))
        return None
    
    def get_online_area(self, info):
        """从在线IP库返回结果提取地区信息"""
        area = ""
        country = info.get("country", "")
        if country == "保留":
            return "内网IP"
        province = info.get("province", "")
        city = info.get("city","")
        region = info.get("region", "")
        
        if not region:
            if province and city:
                if province != city:
                    area = "{},{}".format(province, city)
                else:
                    area = province
        else:
            if city and province:
                if city != province:
                    area = "{},{},{}".format(province,city,region)
                else:
                    area = "{},{}".format(province,region)
            elif city:
                area = "{},{}".format(city,region)
            elif province:
                area = "{},{}".format(province, region)

        if not area:
            if country:
                if country == "中国":
                    if province:
                        area = province
                    else:
                        area = country
                else:
                    if province:
                        area = "{},{}".format(country, province)
                    else:
                        area = country
        return area

    def change_history_data_dir(self, get):
        """更改历史日志数据的存储目录，释放/www/目录下的存储空间"""
        target_dir = ""
        if "target_dir" in get:
            target_dir = get.target_dir
        target_dir = os.path.abspath(target_dir)
        if not os.path.exists(target_dir):
            os.mkdirs(target_dir)

        config_file = "/www/server/total/config.json" 
        config = json.loads(public.readFile(config_file))
        global_config = config["global"]
        # ori_history_data_dir = ""
        # if "history_data_dir" in global_config:
        #     ori_history_data_dir = global_config["history_data_dir"]

        import shutil
        sites = public.M('sites').field('name').order("addtime").select();
        sites.append({'name': "btunknownbt"})
        for site_info in sites:
            site_name = site_info["name"]
            site_history_data_file = tool.get_log_db_path(site_name, history=True)
            new_site_history_data_dir = os.path.join(target_dir, site_name)
            if not os.path.exists(new_site_history_data_dir):
                os.mkdir(new_site_history_data_dir)
            new_history_data_file = os.path.join(new_site_history_data_dir, "history_logs.db")
            if os.path.exists(site_history_data_file) and site_history_data_file != new_site_history_data_dir:
                print("正在移动{} 到 {}".format(site_history_data_file, new_history_data_file))
                public.ExecShell("chown -R www:www {}".format(new_site_history_data_dir))
                shutil.move(site_history_data_file, new_history_data_file)
        
        global_config["history_data_dir"] = target_dir
        public.writeFile(config_file, json.dumps(config))
        return public.returnMsg(True, "历史数据目录切换成功。")